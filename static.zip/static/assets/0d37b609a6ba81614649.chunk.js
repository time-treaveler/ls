"use strict";(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[8816],{804591:(e,t,r)=>{r.d(t,{Z:()=>o});var i=r(897538);const o=(0,r(751995).iK)(i.Z.Item)`
  ${({theme:e})=>`\n    .ant-form-item-label {\n      padding-bottom: ${e.gridUnit}px;\n      & > label {\n        text-transform: uppercase;\n        font-size: ${e.typography.sizes.s}px;\n        color: ${e.colors.grayscale.base};\n\n        &.ant-form-item-required:not(.ant-form-item-required-mark-optional) {\n          &::before {\n            display: none;\n          }\n          &::after {\n            display: inline-block;\n            color: ${e.colors.error.base};\n            font-size: ${e.typography.sizes.s}px;\n            content: '*';\n          }\n        }\n      }\n    }\n  `}
`},902857:(e,t,r)=>{r.d(t,{Z:()=>a});var i=r(751995),o=r(135944);const n=i.iK.label`
  text-transform: uppercase;
  font-size: ${({theme:e})=>e.typography.sizes.s}px;
  color: ${({theme:e})=>e.colors.grayscale.base};
  margin-bottom: ${({theme:e})=>e.gridUnit}px;
`,l=i.iK.label`
  text-transform: uppercase;
  font-size: ${({theme:e})=>e.typography.sizes.s}px;
  color: ${({theme:e})=>e.colors.grayscale.base};
  margin-bottom: ${({theme:e})=>e.gridUnit}px;
  &::after {
    display: inline-block;
    margin-left: ${({theme:e})=>e.gridUnit}px;
    color: ${({theme:e})=>e.colors.error.base};
    font-size: ${({theme:e})=>e.typography.sizes.m}px;
    content: '*';
  }
`;function a({children:e,htmlFor:t,required:r=!1,className:i}){const a=r?l:n;return(0,o.tZ)(a,{htmlFor:t,className:i,children:e})}},73684:(e,t,r)=>{r.d(t,{Z:()=>K});var i,o=r(477808),n=r(931097),l=r(751995),a=r(211965),s=r(61988),d=r(608272),c=r(313322),p=r(835932),h=r(667294);function m(){return m=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e},m.apply(this,arguments)}const g=({title:e,titleId:t,...r},o)=>h.createElement("svg",m({xmlns:"http://www.w3.org/2000/svg",width:24,height:24,fill:"none",ref:o,"aria-labelledby":t},r),e?h.createElement("title",{id:t},e):null,i||(i=h.createElement("path",{fill:"currentColor",fillRule:"evenodd",d:"M12 7a1 1 0 0 0-1 1v4a1 1 0 1 0 2 0V8a1 1 0 0 0-1-1m0 8a1 1 0 1 0 0 2 1 1 0 0 0 0-2m9.71-7.44-5.27-5.27a1.05 1.05 0 0 0-.71-.29H8.27a1.05 1.05 0 0 0-.71.29L2.29 7.56a1.05 1.05 0 0 0-.29.71v7.46c.004.265.107.518.29.71l5.27 5.27c.192.183.445.286.71.29h7.46a1.05 1.05 0 0 0 .71-.29l5.27-5.27a1.05 1.05 0 0 0 .29-.71V8.27a1.05 1.05 0 0 0-.29-.71M20 15.31 15.31 20H8.69L4 15.31V8.69L8.69 4h6.62L20 8.69z",clipRule:"evenodd"}))),u=(0,h.forwardRef)(g);var b=r(804591),v=r(902857),f=r(135944);const x=(0,l.iK)(o.Z)`
  margin: ${({theme:e})=>`${e.gridUnit}px 0 ${2*e.gridUnit}px`};
`,Z=(0,l.iK)(o.Z.Password)`
  margin: ${({theme:e})=>`${e.gridUnit}px 0 ${2*e.gridUnit}px`};
`,$=(0,l.iK)("div")`
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  margin-bottom: ${({theme:e})=>3*e.gridUnit}px;
  .ant-form-item {
    margin-bottom: 0;
  }
`,y=l.iK.div`
  display: flex;
  align-items: center;
`,w=(0,l.iK)(v.Z)`
  margin-bottom: 0;
`,k=a.iv`
  &.anticon > * {
    line-height: 0;
  }
`,K=({label:e,validationMethods:t,errorMessage:r,helpText:i,required:o=!1,hasTooltip:l=!1,tooltipText:h,id:m,className:g,visibilityToggle:v,get_url:K,description:z,...U})=>(0,f.BX)($,{className:g,children:[(0,f.BX)(y,{children:[(0,f.tZ)(w,{htmlFor:m,required:o,children:e}),l&&(0,f.tZ)(d.Z,{tooltip:`${h}`})]}),(0,f.BX)(b.Z,{css:e=>((e,t)=>a.iv`
  .ant-form-item-children-icon {
    display: none;
  }
  ${t&&`.ant-form-item-control-input-content {\n      position: relative;\n      &:after {\n        content: ' ';\n        display: inline-block;\n        background: ${e.colors.error.base};\n        mask: url(${u});\n        mask-size: cover;\n        width: ${4*e.gridUnit}px;\n        height: ${4*e.gridUnit}px;\n        position: absolute;\n        right: ${1.25*e.gridUnit}px;\n        top: ${2.75*e.gridUnit}px;\n      }\n    }`}
`)(e,!!r),validateTrigger:Object.keys(t),validateStatus:r?"error":"success",help:r||i,hasFeedback:!!r,children:[v||"password"===U.name?(0,f.tZ)(Z,{...U,...t,iconRender:e=>e?(0,f.tZ)(n.Z,{title:(0,s.t)("Hide password."),children:(0,f.tZ)(c.Z.EyeInvisibleOutlined,{iconSize:"m",css:k})}):(0,f.tZ)(n.Z,{title:(0,s.t)("Show password."),children:(0,f.tZ)(c.Z.EyeOutlined,{iconSize:"m",css:k,"data-test":"icon-eye"})}),role:"textbox"}):(0,f.tZ)(x,{...U,...t}),K&&z?(0,f.BX)(p.Z,{type:"link",htmlType:"button",buttonStyle:"default",onClick:()=>(window.open(K),!0),children:["Get ",z]}):(0,f.tZ)("br",{})]})]})},49238:(e,t,r)=>{r.d(t,{l0:()=>a,xJ:()=>s.Z,lX:()=>d.Z,QA:()=>c.Z});var i=r(897538),o=r(751995),n=r(135944);const l=(0,o.iK)(i.Z)`
  &.ant-form label {
    font-size: ${({theme:e})=>e.typography.sizes.s}px;
  }
  .ant-form-item {
    margin-bottom: ${({theme:e})=>4*e.gridUnit}px;
  }
`;function a(e){return(0,n.tZ)(l,{...e})}var s=r(804591),d=r(902857),c=r(73684)},608272:(e,t,r)=>{r.d(t,{Z:()=>p});var i=r(751995),o=r(358593),n=r(313322),l=r(135944);const a=(0,i.iK)(o.u)`
  cursor: pointer;
`,s=i.iK.span`
  display: -webkit-box;
  -webkit-line-clamp: 20;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
`,d={fontSize:"12px",lineHeight:"16px"},c="rgba(0,0,0,0.9)";function p({tooltip:e,iconStyle:t={},placement:r="right",trigger:o="hover",overlayStyle:p=d,bgColor:h=c,viewBox:m="0 -1 24 24"}){const g=(0,i.Fg)(),u={...t,color:t.color||g.colors.grayscale.base};return(0,l.tZ)(a,{title:(0,l.tZ)(s,{children:e}),placement:r,trigger:o,overlayStyle:p,color:h,children:(0,l.tZ)(n.Z.InfoSolidSmall,{style:u,viewBox:m})})}},9875:(e,t,r)=>{r.d(t,{II:()=>l,Kx:()=>s,Rn:()=>a});var i=r(751995),o=r(477808),n=r(114112);const l=(0,i.iK)(o.Z)`
  border: 1px solid ${({theme:e})=>e.colors.secondary.light3};
  border-radius: ${({theme:e})=>e.borderRadius}px;
`,a=(0,i.iK)(n.Z)`
  border: 1px solid ${({theme:e})=>e.colors.secondary.light3};
  border-radius: ${({theme:e})=>e.borderRadius}px;
`,s=(0,i.iK)(o.Z.TextArea)`
  border: 1px solid ${({theme:e})=>e.colors.secondary.light3};
  border-radius: ${({theme:e})=>e.borderRadius}px;
`},287183:(e,t,r)=>{r.d(t,{Y:()=>a});var i=r(751995),o=r(747933);const n=(0,i.iK)(o.ZP)`
  .ant-radio-inner {
    top: -1px;
    left: 2px;
    width: ${({theme:e})=>4*e.gridUnit}px;
    height: ${({theme:e})=>4*e.gridUnit}px;
    border-width: 2px;
    border-color: ${({theme:e})=>e.colors.grayscale.light2};
  }

  .ant-radio.ant-radio-checked {
    .ant-radio-inner {
      border-width: ${({theme:e})=>e.gridUnit+1}px;
      border-color: ${({theme:e})=>e.colors.primary.base};
    }

    .ant-radio-inner::after {
      background-color: ${({theme:e})=>e.colors.grayscale.light5};
      top: 0;
      left: 0;
      width: ${({theme:e})=>e.gridUnit+2}px;
      height: ${({theme:e})=>e.gridUnit+2}px;
    }
  }

  .ant-radio:hover,
  .ant-radio:focus {
    .ant-radio-inner {
      border-color: ${({theme:e})=>e.colors.primary.dark1};
    }
  }
`,l=(0,i.iK)(o.ZP.Group)`
  font-size: inherit;
`,a=Object.assign(n,{Group:l,Button:o.ZP.Button})},482342:(e,t,r)=>{r.d(t,{Z:()=>m});var i=r(667294),o=r(211965),n=r(751995),l=r(61988),a=r(409882),s=r(358593),d=r(49238),c=r(313322),p=r(135944);const h=o.iv`
  &.anticon {
    font-size: unset;
    .anticon {
      line-height: unset;
      vertical-align: unset;
    }
  }
`,m=({name:e,label:t,description:r,validationErrors:m=[],renderTrigger:g=!1,rightNode:u,leftNode:b,onClick:v,hovered:f=!1,tooltipOnClick:x=(()=>{}),warning:Z,danger:$})=>{const{gridUnit:y,colors:w}=(0,n.Fg)(),k=(0,i.useRef)(!1),K=(0,i.useMemo)((()=>(m.length||(k.current=!0),k.current?m.length?w.error.base:"unset":w.alert.base)),[w.error.base,w.alert.base,m.length]);return t?(0,p.BX)("div",{className:"ControlHeader","data-test":`${e}-header`,children:[(0,p.tZ)("div",{className:"pull-left",children:(0,p.BX)(d.lX,{css:e=>o.iv`
            margin-bottom: ${.5*e.gridUnit}px;
            position: relative;
          `,children:[b&&(0,p.tZ)("span",{children:b}),(0,p.tZ)("span",{role:"button",tabIndex:0,onClick:v,style:{cursor:v?"pointer":""},children:t})," ",Z&&(0,p.BX)("span",{children:[(0,p.tZ)(s.u,{id:"error-tooltip",placement:"top",title:Z,children:(0,p.tZ)(c.Z.AlertSolid,{iconColor:w.alert.base,iconSize:"s"})})," "]}),$&&(0,p.BX)("span",{children:[(0,p.tZ)(s.u,{id:"error-tooltip",placement:"top",title:$,children:(0,p.tZ)(c.Z.ErrorSolid,{iconColor:w.error.base,iconSize:"s"})})," "]}),(null==m?void 0:m.length)>0&&(0,p.BX)("span",{"data-test":"error-tooltip",children:[(0,p.tZ)(s.u,{id:"error-tooltip",placement:"top",title:null==m?void 0:m.join(" "),children:(0,p.tZ)(c.Z.ExclamationCircleOutlined,{css:o.iv`
                    ${h};
                    color: ${K};
                  `})})," "]}),f?(0,p.BX)("span",{css:()=>o.iv`
          position: absolute;
          top: 50%;
          right: 0;
          padding-left: ${y}px;
          transform: translate(100%, -50%);
          white-space: nowrap;
        `,children:[r&&(0,p.BX)("span",{children:[(0,p.tZ)(s.u,{id:"description-tooltip",title:r,placement:"top",children:(0,p.tZ)(c.Z.InfoCircleOutlined,{css:h,onClick:x})})," "]}),g&&(0,p.BX)("span",{children:[(0,p.tZ)(a.V,{label:(0,l.t)("bolt"),tooltip:(0,l.t)("Changing this control takes effect instantly"),placement:"top",icon:"bolt"})," "]})]}):null]})}),u&&(0,p.tZ)("div",{className:"pull-right",children:u}),(0,p.tZ)("div",{className:"clearfix"})]}):null}},89483:(e,t,r)=>{r.r(t),r.d(t,{default:()=>p});var i=r(751995),o=r(5364),n=r(667294),l=r(101090),a=r(174448),s=r(135944);const d=(0,i.iK)(a.un)`
  display: flex;
  align-items: center;
  overflow-x: auto;

  & .ant-tag {
    margin-right: 0;
  }
`,c=i.iK.div`
  display: flex;
  height: 100%;
  max-width: 100%;
  width: 100%;
  & > div,
  & > div:hover {
    ${({validateStatus:e,theme:t})=>{var r;return e&&`border-color: ${null==(r=t.colors[e])?void 0:r.base}`}}
  }
`;function p(e){var t;const{setDataMask:r,setHoveredFilter:i,unsetHoveredFilter:a,setFocusedFilter:p,unsetFocusedFilter:h,setFilterActive:m,width:g,height:u,filterState:b,inputRef:v,isOverflowingFilterBar:f=!1}=e,x=(0,n.useCallback)((e=>{const t=e&&e!==o.vM;r({extraFormData:t?{time_range:e}:{},filterState:{value:t?e:void 0}})}),[r]);return(0,n.useEffect)((()=>{x(b.value)}),[b.value]),null!=(t=e.formData)&&t.inView?(0,s.tZ)(d,{width:g,height:u,children:(0,s.tZ)(c,{ref:v,validateStatus:b.validateStatus,onFocus:p,onBlur:h,onMouseEnter:i,onMouseLeave:a,children:(0,s.tZ)(l.ZP,{value:b.value||o.vM,name:"time_range",onChange:x,onOpenPopover:()=>m(!0),onClosePopover:()=>{m(!1),a(),h()},isOverflowingFilterBar:f})})}):null}},174448:(e,t,r)=>{r.d(t,{Am:()=>s,h2:()=>n,jp:()=>a,un:()=>l});var i=r(751995),o=r(804591);const n=0,l=i.iK.div`
  min-height: ${({height:e})=>e}px;
  width: ${({width:e})=>e===n?"100%":`${e}px`};
`,a=(0,i.iK)(o.Z)`
  &.ant-row.ant-form-item {
    margin: 0;
  }
`,s=i.iK.div`
  color: ${({theme:e,status:t="error"})=>{var r;return null==(r=e.colors[t])?void 0:r.base}};
`}}]);
//# sourceMappingURL=0d37b609a6ba81614649.chunk.js.map