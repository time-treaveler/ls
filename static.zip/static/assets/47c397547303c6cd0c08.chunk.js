"use strict";(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[7317],{542878:(e,t,a)=>{a.d(t,{Z:()=>g});var n=a(667294),l=a(45697),r=a.n(l),i=a(9875),o=a(61988),s=a(468135),d=a(835932),c=a(794670),u=a(601304),h=a(482342),p=a(135944);const m={name:r().string,onChange:r().func,initialValue:r().string,height:r().number,minLines:r().number,maxLines:r().number,offerEditInModal:r().bool,language:r().oneOf([null,"json","html","sql","markdown","javascript"]),aboveEditorSection:r().node,readOnly:r().bool,resize:r().oneOf([null,"block","both","horizontal","inline","none","vertical"]),textAreaStyles:r().object};class v extends n.Component{onControlChange(e){const{value:t}=e.target;this.props.onChange(t)}onAreaEditorChange(e){this.props.onChange(e)}renderEditor(e=!1){const t=e?40:this.props.minLines||12;if(this.props.language){const a={border:`1px solid ${this.props.theme.colors.grayscale.light1}`,minHeight:`${t}em`,width:"auto",...this.props.textAreaStyles};return this.props.resize&&(a.resize=this.props.resize),this.props.readOnly&&(a.backgroundColor="#f2f2f2"),(0,p.tZ)(c.YH,{mode:this.props.language,style:a,minLines:t,maxLines:e?1e3:this.props.maxLines,editorProps:{$blockScrolling:!0},defaultValue:this.props.initialValue,readOnly:this.props.readOnly,...this.props,onChange:this.onAreaEditorChange.bind(this)},this.props.name)}return(0,p.tZ)(i.Kx,{placeholder:(0,o.t)("textarea"),onChange:this.onControlChange.bind(this),defaultValue:this.props.initialValue,disabled:this.props.readOnly,style:{height:this.props.height}})}renderModalBody(){return(0,p.BX)(p.HY,{children:[(0,p.tZ)("div",{children:this.props.aboveEditorSection}),this.renderEditor(!0)]})}render(){const e=(0,p.tZ)(h.Z,{...this.props});return(0,p.BX)("div",{children:[e,this.renderEditor(),this.props.offerEditInModal&&(0,p.tZ)(u.Z,{modalTitle:e,triggerNode:(0,p.BX)(d.Z,{buttonSize:"small",className:"m-t-5",children:[(0,o.t)("Edit")," ",(0,p.tZ)("strong",{children:this.props.language})," ",(0,o.t)("in modal")]}),modalBody:this.renderModalBody(!0),responsive:!0})]})}}v.propTypes=m,v.defaultProps={onChange:()=>{},initialValue:"",height:250,minLines:3,maxLines:10,offerEditInModal:!0,readOnly:!1,resize:null,textAreaStyles:{}};const g=(0,s.b)(v)},109433:(e,t,a)=>{a.d(t,{Bj:()=>d});var n=a(738179),l=a(61988),r=a(751995),i=a(361247),o=a(135944);const s={everyText:(0,l.t)("every"),emptyMonths:(0,l.t)("every month"),emptyMonthDays:(0,l.t)("every day of the month"),emptyMonthDaysShort:(0,l.t)("day of the month"),emptyWeekDays:(0,l.t)("every day of the week"),emptyWeekDaysShort:(0,l.t)("day of the week"),emptyHours:(0,l.t)("every hour"),emptyMinutes:(0,l.t)("every minute"),emptyMinutesForHourPeriod:(0,l.t)("every"),yearOption:(0,l.t)("year"),monthOption:(0,l.t)("month"),weekOption:(0,l.t)("week"),dayOption:(0,l.t)("day"),hourOption:(0,l.t)("hour"),minuteOption:(0,l.t)("minute"),rebootOption:(0,l.t)("reboot"),prefixPeriod:(0,l.t)("Every"),prefixMonths:(0,l.t)("in"),prefixMonthDays:(0,l.t)("on"),prefixWeekDays:(0,l.t)("on"),prefixWeekDaysForMonthAndYearPeriod:(0,l.t)("or"),prefixHours:(0,l.t)("at"),prefixMinutes:(0,l.t)(":"),prefixMinutesForHourPeriod:(0,l.t)("at"),suffixMinutesForHourPeriod:(0,l.t)("minute(s)"),errorInvalidCron:(0,l.t)("Invalid cron expression"),clearButtonText:(0,l.t)("Clear"),weekDays:[(0,l.t)("Sunday"),(0,l.t)("Monday"),(0,l.t)("Tuesday"),(0,l.t)("Wednesday"),(0,l.t)("Thursday"),(0,l.t)("Friday"),(0,l.t)("Saturday")],months:[(0,l.t)("January"),(0,l.t)("February"),(0,l.t)("March"),(0,l.t)("April"),(0,l.t)("May"),(0,l.t)("June"),(0,l.t)("July"),(0,l.t)("August"),(0,l.t)("September"),(0,l.t)("October"),(0,l.t)("November"),(0,l.t)("December")],altWeekDays:[(0,l.t)("SUN"),(0,l.t)("MON"),(0,l.t)("TUE"),(0,l.t)("WED"),(0,l.t)("THU"),(0,l.t)("FRI"),(0,l.t)("SAT")],altMonths:[(0,l.t)("JAN"),(0,l.t)("FEB"),(0,l.t)("MAR"),(0,l.t)("APR"),(0,l.t)("MAY"),(0,l.t)("JUN"),(0,l.t)("JUL"),(0,l.t)("AUG"),(0,l.t)("SEP"),(0,l.t)("OCT"),(0,l.t)("NOV"),(0,l.t)("DEC")]},d=(0,r.iK)((e=>(0,o.tZ)(n.ZP,{getPopupContainer:e=>e.parentElement,children:(0,o.tZ)(i.Z,{locale:s,...e})})))`
  ${({theme:e})=>`\n\n    /* Boilerplate styling for ReactCronPicker imported explicitly in GlobalStyles.tsx */\n\n    /* When year period is selected */\n\n    :has(.react-js-cron-months) {\n      display: grid !important;\n      grid-template-columns: repeat(2, 50%);\n      column-gap: ${e.gridUnit}px;\n      row-gap: ${2*e.gridUnit}px;\n      div:has(.react-js-cron-hours) {\n        grid-column: span 2;\n        display: flex;\n        justify-content: space-between;\n        .react-js-cron-field {\n          width: 50%;\n        }\n      }\n    }\n\n    /* When month period is selected */\n\n    :not(:has(.react-js-cron-months)) {\n      display: grid;\n      grid-template-columns: repeat(2, 50%);\n      column-gap: ${e.gridUnit}px;\n      row-gap: ${2*e.gridUnit}px;\n      .react-js-cron-period {\n        grid-column: span 2;\n      }\n      div:has(.react-js-cron-hours) {\n        grid-column: span 2;\n        display: flex;\n        justify-content: space-between;\n        .react-js-cron-field {\n          width: 50%;\n        }\n      }\n    }\n\n    /* When week period is selected */\n\n    :not(:has(.react-js-cron-month-days)) {\n      .react-js-cron-week-days {\n        grid-column: span 2;\n      }\n    }\n\n    /* For proper alignment of inputs and span elements */\n\n    :not(div:has(.react-js-cron-hours)) {\n      display: flex;\n      flex-wrap: nowrap;\n    }\n\n    div:has(.react-js-cron-hours) {\n      width: 100%;\n    }\n\n    .react-js-cron-minutes > span {\n      padding-left: ${e.gridUnit}px;\n    }\n\n    /* Sizing of select container */\n\n    .react-js-cron-select.ant-select {\n      width: 100%;\n      .ant-select-selector {\n        flex-wrap: nowrap;\n      }\n    }\n\n    .react-js-cron-field {\n      width: 100%;\n      margin-bottom: 0px;\n      > span {\n        margin-left: 0px;\n      }\n    }\n\n    .react-js-cron-custom-select .ant-select-selection-placeholder {\n      flex: auto;\n      border-radius: ${e.gridUnit}px;\n    }\n\n    .react-js-cron-custom-select .ant-select-selection-overflow-item {\n      align-self: center;\n    }\n\n    .react-js-cron-select > div:first-of-type,\n    .react-js-cron-custom-select {\n      border-radius: ${e.gridUnit}px;\n    }\n  `}
`},898978:(e,t,a)=>{a.d(t,{Z:()=>N});var n=a(211965),l=a(667294),r=a(480008),i=a.n(r),o=a(61988),s=a(104715),d=a(135944);const c="GMT Standard Time",u="400px",h={"-300-240":["Eastern Standard Time","Eastern Daylight Time"],"-360-300":["Central Standard Time","Central Daylight Time"],"-420-360":["Mountain Standard Time","Mountain Daylight Time"],"-420-420":["Mountain Standard Time - Phoenix","Mountain Standard Time - Phoenix"],"-480-420":["Pacific Standard Time","Pacific Daylight Time"],"-540-480":["Alaska Standard Time","Alaska Daylight Time"],"-600-600":["Hawaii Standard Time","Hawaii Daylight Time"],60120:["Central European Time","Central European Daylight Time"],"00":[c,c],"060":["GMT Standard Time - London","British Summer Time"]},p=i()(),m=i()([2021,1]),v=i()([2021,7]),g=e=>m.tz(e).utcOffset().toString()+v.tz(e).utcOffset().toString(),b=e=>{var t,a;const n=g(e);return(p.tz(e).isDST()?null==(t=h[n])?void 0:t[1]:null==(a=h[n])?void 0:a[0])||e},E=i().tz.countries().map((e=>i().tz.zonesForCountry(e,!0))).flat(),T=[];E.forEach((e=>{T.find((t=>g(t.name)===g(e.name)))||T.push(e)}));const f=T.map((e=>({label:`GMT ${i().tz(p,e.name).format("Z")} (${b(e.name)})`,value:e.name,offsets:g(e.name),timezoneName:e.name}))),_=(e,t)=>i().tz(p,e.timezoneName).utcOffset()-i().tz(p,t.timezoneName).utcOffset();f.sort(_);const y=e=>{var t;return(null==(t=f.find((t=>t.offsets===g(e))))?void 0:t.value)||"Africa/Abidjan"};function N({onTimezoneChange:e,timezone:t,minWidth:a=u}){const r=(0,l.useMemo)((()=>y(t||i().tz.guess())),[t]);return(0,l.useEffect)((()=>{t!==r&&e(r)}),[r,e,t]),(0,d.tZ)(s.Ph,{ariaLabel:(0,o.t)("Timezone selector"),css:(0,n.iv)({minWidth:a},"",""),onChange:t=>e(t),value:r,options:f,sortComparator:_})}},567317:(e,t,a)=>{a.d(t,{j5:()=>K,KL:()=>ae,ZP:()=>le});var n=a(667294),l=a(61988),r=a(211965),i=a(751995),o=a(593185),s=a(431069),d=a(115926),c=a.n(d),u=a(34858),h=a(9875),p=a(112441),m=a(774069),v=a(843700),g=a(898978),b=a(985633),E=a(414114),T=a(104715),f=a(542878),_=a(418451),y=a(409882),N=a(690335),R=a(828216),S=a(135944);function x({timeUnit:e,min:t,name:a,value:l,placeholder:r,onChange:i}){const[o,s]=(0,n.useState)(!1);return(0,S.tZ)("input",{type:"text",min:t,name:a,value:l?`${l}${o?"":` ${e}`}`:"",placeholder:r,onFocus:()=>s(!0),onBlur:()=>s(!1),onChange:i})}var C,Z=a(109433);!function(e){e.Picker="picker",e.Input="input"}(C||(C={}));const O=[{label:(0,l.t)("Recurring (every)"),value:C.Picker},{label:(0,l.t)("CRON Schedule"),value:C.Input}],A=({value:e,onChange:t})=>{const a=(0,i.Fg)(),r=(0,n.useRef)(null),[o,s]=(0,n.useState)(C.Picker),d=(0,n.useCallback)((e=>{var a;t(e),null==(a=r.current)||a.setValue(e)}),[r,t]),c=(0,n.useCallback)((e=>{t(e.target.value)}),[t]),u=(0,n.useCallback)((()=>{var e;t((null==(e=r.current)?void 0:e.input.value)||"")}),[t]),[p,m]=(0,n.useState)();return(0,S.BX)(S.HY,{children:[(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Schedule type"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)(T.Ph,{ariaLabel:(0,l.t)("Schedule type"),placeholder:(0,l.t)("Schedule type"),onChange:e=>{s(e)},value:o,options:O})})]}),(0,S.BX)(K,{"data-test":"input-content",className:"styled-input",children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Schedule"),(0,S.tZ)("span",{className:"required",children:"*"})]}),o===C.Input&&(0,S.tZ)(h.II,{type:"text",name:"crontab",ref:r,style:p?{borderColor:a.colors.error.base}:{},placeholder:(0,l.t)("CRON expression"),value:e,onBlur:c,onChange:e=>d(e.target.value),onPressEnter:u}),o===C.Picker&&(0,S.tZ)(Z.Bj,{clearButton:!1,value:e,setValue:d,displayError:o===C.Picker,onError:m})]})]})};var L=a(313322);const I=i.iK.div`
  margin-bottom: 10px;

  .input-container {
    textarea {
      height: auto;
    }

    &.error {
      input {
        border-color: ${({theme:e})=>e.colors.error.base};
      }
    }
  }

  .inline-container {
    margin-bottom: 10px;

    > div {
      margin: 0;
    }

    .delete-button {
      margin-left: 10px;
      padding-top: 3px;
    }
  }
`,w={EMAIL_SUBJECT_NAME:(0,l.t)("Email subject name (optional)"),EMAIL_SUBJECT_ERROR_TEXT:(0,l.t)("Please enter valid text. Spaces alone are not permitted.")},B=({setting:e=null,index:t,onUpdate:a,onRemove:r,onInputChange:o,email_subject:s,defaultSubject:d,setErrorSubject:c})=>{const{method:u,recipients:h,options:p}=e||{},[m,v]=(0,n.useState)(h||""),[g,b]=(0,n.useState)(!1),E=(0,i.Fg)();return e?(h&&m!==h&&v(h),(0,S.BX)(I,{children:[(0,S.tZ)("div",{className:"inline-container",children:(0,S.BX)(K,{children:[(0,S.tZ)("div",{className:"control-label",children:(0,l.t)("Notification Method")}),(0,S.BX)("div",{className:"input-container",children:[(0,S.tZ)(T.Ph,{ariaLabel:(0,l.t)("Delivery method"),"data-test":"select-delivery-method",onChange:n=>{if(v(""),a){const l={...e,method:n,recipients:""};a(t,l)}},placeholder:(0,l.t)("Select Delivery Method"),options:(p||[]).map((e=>({label:e,value:e}))),value:u}),0!==t&&r?(0,S.tZ)("span",{role:"button",tabIndex:0,className:"delete-button",onClick:()=>r(t),children:(0,S.tZ)(L.Z.Trash,{iconColor:E.colors.grayscale.base})}):null]})]})}),void 0!==u?(0,S.BX)(S.HY,{children:[(0,S.tZ)("div",{className:"inline-container",children:(0,S.tZ)(K,{children:"Email"===u?(0,S.BX)(S.HY,{children:[(0,S.tZ)("div",{className:"control-label",children:w.EMAIL_SUBJECT_NAME}),(0,S.tZ)("div",{className:"input-container "+(g?"error":""),children:(0,S.tZ)("input",{type:"text",name:"email_subject",value:s,placeholder:d,onChange:e=>{const{value:t}=e.target;o&&o(e);const a=t.length>0&&0===t.trim().length;b(a),c&&c(a)}})}),g&&(0,S.tZ)("div",{style:{color:E.colors.error.base,fontSize:3*E.gridUnit},children:w.EMAIL_SUBJECT_ERROR_TEXT})]}):null})}),(0,S.tZ)("div",{className:"inline-container",children:(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("%s recipients",u),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)("textarea",{name:"recipients","data-test":"recipients",value:m,onChange:n=>{const{target:l}=n;if(v(l.value),a){const n={...e,recipients:l.value};a(t,n)}}})}),(0,S.tZ)("div",{className:"helper",children:(0,l.t)('Recipients are separated by "," or ";"')})]})})]}):null]})):null};var X=a(840695);const k=({title:e,subtitle:t,validateCheckStatus:a,testId:n})=>{const r=(0,S.tZ)(X.Z,{});return(0,S.BX)("div",{className:"collapse-panel-header",children:[(0,S.BX)("div",{className:"collapse-panel-title","data-test":n,children:[(0,S.tZ)("span",{children:(0,l.t)(e)}),a?(0,S.tZ)("span",{className:"validation-checkmark",children:r}):(0,S.tZ)("span",{className:"collapse-panel-asterisk",children:" *"})]}),(0,S.tZ)("p",{className:"collapse-panel-subtitle",children:t?(0,l.t)(t):void 0})]})};var j=a(427279);const $=e=>(0,S.tZ)(j.Z.Panel,{css:e=>(e=>r.iv`
  .ant-collapse-header {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    padding: 0px ${4*e.gridUnit}px;

    .anticon.anticon-right.ant-collapse-arrow {
      padding: 0;
      top: calc(50% - ${6}px);
    }

    .collapse-panel-title {
      font-size: ${4*e.gridUnit}px;
      font-weight: ${e.typography.weights.bold};
      line-height: 130%;
    }

    .collapse-panel-subtitle {
      color: ${e.colors.grayscale.base};
      font-size: ${e.typography.sizes.s}px;
      font-weight: ${e.typography.weights.normal};
      line-height: 150%;
      margin-bottom: 0;
      padding-top: ${e.gridUnit}px;
    }

    .collapse-panel-asterisk {
      color: var(--semantic-error-base, ${e.colors.warning.dark1});
    }
    .validation-checkmark {
      width: ${4*e.gridUnit}px;
      height: ${4*e.gridUnit}px;
      margin-left: ${e.gridUnit}px;
      color: ${e.colors.success.base};
    }
  }
`)(e),...e}),U=i.iK.ul`
  margin-left: ${({theme:e})=>2*e.gridUnit}px;
  padding-inline-start: ${({theme:e})=>3*e.gridUnit}px;
`,P=["pivot_table_v2","table","paired_ttest"],M=["Email"],D="PNG",z=[{label:(0,l.t)("< (Smaller than)"),value:"<"},{label:(0,l.t)("> (Larger than)"),value:">"},{label:(0,l.t)("<= (Smaller or equal)"),value:"<="},{label:(0,l.t)(">= (Larger or equal)"),value:">="},{label:(0,l.t)("== (Is equal)"),value:"=="},{label:(0,l.t)("!= (Is not equal)"),value:"!="},{label:(0,l.t)("Not null"),value:"not null"}],q=[{label:(0,l.t)("None"),value:0},{label:(0,l.t)("30 days"),value:30},{label:(0,l.t)("60 days"),value:60},{label:(0,l.t)("90 days"),value:90}],F=[{label:(0,l.t)("Dashboard"),value:"dashboard"},{label:(0,l.t)("Chart"),value:"chart"}],G={pdf:{label:(0,l.t)("Send as PDF"),value:"PDF"},png:{label:(0,l.t)("Send as PNG"),value:"PNG"},csv:{label:(0,l.t)("Send as CSV"),value:"CSV"},txt:{label:(0,l.t)("Send as text"),value:"TEXT"}},H=r.iv`
  margin-bottom: 0;
`,W=(0,i.iK)(m.default)`
  .ant-modal-body {
    height: 720px;
  }

  .control-label {
    margin-top: ${({theme:e})=>e.gridUnit}px;
  }

  .ant-collapse > .ant-collapse-item {
    border-bottom: none;
  }

  .inline-container {
    display: flex;
    flex-direction: row;
    align-items: center;
    &.wrap {
      flex-wrap: wrap;
    }

    > div {
      flex: 1 1 auto;
    }
  }
`,V=i.iK.div`
  display: flex;
  align-items: center;
  margin-top: 10px;

  .switch-label {
    margin-left: 10px;
  }
`,K=i.iK.div`
  ${({theme:e})=>r.iv`
    flex: 1;
    margin-top: 0px;
    margin-bottom: ${4*e.gridUnit}px;

    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    input[type='number'] {
      -moz-appearance: textfield;
    }

    .helper {
      display: block;
      color: ${e.colors.grayscale.base};
      font-size: ${e.typography.sizes.s}px;
      padding: ${e.gridUnit}px 0;
      text-align: left;
    }

    .required {
      margin-left: ${e.gridUnit/2}px;
      color: ${e.colors.error.base};
    }

    .input-container {
      display: flex;
      align-items: center;

      > div {
        width: 100%;
      }

      label {
        display: flex;
        margin-right: ${2*e.gridUnit}px;
      }

      i {
        margin: 0 ${e.gridUnit}px;
      }
    }

    input,
    textarea {
      flex: 1 1 auto;
    }

    input[disabled] {
      color: ${e.colors.grayscale.base};
    }

    textarea {
      height: 300px;
      resize: none;
    }

    input::placeholder,
    textarea::placeholder {
      color: ${e.colors.grayscale.light1};
    }

    textarea,
    input[type='text'],
    input[type='number'] {
      padding: ${e.gridUnit}px ${2*e.gridUnit}px;
      border-style: none;
      border: 1px solid ${e.colors.grayscale.light2};
      border-radius: ${e.gridUnit}px;

      &[name='description'] {
        flex: 1 1 auto;
      }
    }

    .input-label {
      margin-left: 10px;
    }
  `}
`,J=(0,i.iK)(T.r4)`
  margin-top: ${({theme:e})=>0*e.gridUnit}px;
`,Y=(0,i.iK)(y.V)`
  margin-left: ${({theme:e})=>e.gridUnit}px;
`,Q=i.iK.div`
  ${({theme:e})=>r.iv`
    color: ${e.colors.primary.dark1};
    cursor: pointer;

    i {
      margin-right: ${2*e.gridUnit}px;
    }

    &.disabled {
      color: ${e.colors.grayscale.light1};
      cursor: default;
    }
  `}
`,ee=i.iK.div`
  .inline-container .input-container {
    margin-left: 0;
  }
`,te=e=>r.iv`
  margin-right: ${3*e.gridUnit}px;
`,ae={GENERAL_TITLE:(0,l.t)("General information"),ALERT_CONDITION_TITLE:(0,l.t)("Alert condition"),ALERT_CONTENTS_TITLE:(0,l.t)("Alert contents"),REPORT_CONTENTS_TITLE:(0,l.t)("Report contents"),SCHEDULE_TITLE:(0,l.t)("Schedule"),NOTIFICATION_TITLE:(0,l.t)("Notification method"),NAME_ERROR_TEXT:(0,l.t)("name"),OWNERS_ERROR_TEXT:(0,l.t)("owners"),CONTENT_ERROR_TEXT:(0,l.t)("content type"),DATABASE_ERROR_TEXT:(0,l.t)("database"),SQL_ERROR_TEXT:(0,l.t)("sql"),ALERT_CONDITION_ERROR_TEXT:(0,l.t)("alert condition"),CRONTAB_ERROR_TEXT:(0,l.t)("crontab"),WORKING_TIMEOUT_ERROR_TEXT:(0,l.t)("working timeout"),RECIPIENTS_ERROR_TEXT:(0,l.t)("recipients"),EMAIL_SUBJECT_ERROR_TEXT:(0,l.t)("email subject"),ERROR_TOOLTIP_MESSAGE:(0,l.t)("Not all required fields are complete. Please provide the following:")},ne=({status:e="active",onClick:t})=>"hidden"===e?null:(0,S.BX)(Q,{className:e,onClick:()=>{"disabled"!==e&&t()},children:[(0,S.tZ)("i",{className:"fa fa-plus"})," ","active"===e?(0,l.t)("Add another notification method"):(0,l.t)("Add delivery method")]}),le=(0,E.ZP)((({addDangerToast:e,onAdd:t,onHide:a,show:i,alert:d=null,isReport:m=!1,addSuccessToast:E})=>{var y,C,Z,O,L,I,w,X;const j=(0,R.v9)((e=>e.user)),Q=(0,_.c)(),le=(null==Q?void 0:Q.ALERT_REPORTS_NOTIFICATION_METHODS)||M,[re,ie]=(0,n.useState)(!0),[oe,se]=(0,n.useState)(),[de,ce]=(0,n.useState)(!0),[ue,he]=(0,n.useState)("dashboard"),[pe,me]=(0,n.useState)(D),[ve,ge]=(0,n.useState)(!1),[be,Ee]=(0,n.useState)(!1);(0,n.useEffect)((()=>{Ee("PNG"===pe)}),[pe]);const[Te,fe]=(0,n.useState)(!1),[_e,ye]=(0,n.useState)([]),[Ne,Re]=(0,n.useState)([]),[Se,xe]=(0,n.useState)([]),[Ce,Ze]=(0,n.useState)({[N.bx.General]:{hasErrors:!1,name:ae.GENERAL_TITLE,errors:[]},[N.bx.Content]:{hasErrors:!1,name:m?ae.REPORT_CONTENTS_TITLE:ae.ALERT_CONTENTS_TITLE,errors:[]},[N.bx.Alert]:{hasErrors:!1,name:ae.ALERT_CONDITION_TITLE,errors:[]},[N.bx.Schedule]:{hasErrors:!1,name:ae.SCHEDULE_TITLE,errors:[]},[N.bx.Notification]:{hasErrors:!1,name:ae.NOTIFICATION_TITLE,errors:[]}}),[Oe,Ae]=(0,n.useState)(""),Le=(e,t)=>{Ze((a=>({...a,[e]:{hasErrors:t.length>0,name:a[e].name,errors:t}})))},[Ie,we]=(0,n.useState)(""),Be=m?"report":"alert",Xe=null!==d,ke=(0,o.cr)(o.TT.AlertsAttachReports)||m,[je,$e]=(0,n.useState)("active"),[Ue,Pe]=(0,n.useState)([]),[Me,De]=(0,n.useState)(""),[ze,qe]=(0,n.useState)(!1),{ALERT_REPORTS_DEFAULT_WORKING_TIMEOUT:Fe,ALERT_REPORTS_DEFAULT_CRON_VALUE:Ge,ALERT_REPORTS_DEFAULT_RETENTION:He}=(0,R.v9)((e=>{var t,a,n,l;const r=null==(t=e.common)?void 0:t.conf;return{ALERT_REPORTS_DEFAULT_WORKING_TIMEOUT:null!=(a=null==r?void 0:r.ALERT_REPORTS_DEFAULT_WORKING_TIMEOUT)?a:3600,ALERT_REPORTS_DEFAULT_CRON_VALUE:null!=(n=null==r?void 0:r.ALERT_REPORTS_DEFAULT_CRON_VALUE)?n:"0 0 * * *",ALERT_REPORTS_DEFAULT_RETENTION:null!=(l=null==r?void 0:r.ALERT_REPORTS_DEFAULT_RETENTION)?l:90}})),We={active:!0,creation_method:"alerts_reports",crontab:Ge,log_retention:He,working_timeout:Fe,name:"",owners:[],recipients:[],sql:"",email_subject:"",validator_config_json:{},validator_type:"",force_screenshot:!1,grace_period:void 0},Ve=(e,t)=>{const a=[...Ue];a[e]=t,Ue[e].method!==t.method?(Ue[e]=t,Pe(Ue.filter(((t,a)=>a<=e))),Ue.length-1>e&&$e("active"),void 0!==t.method&&"hidden"!==je&&$e("active")):Pe(a)},Ke=e=>{const t=Ue.slice();t.splice(e,1),Pe(t),$e("active")},{state:{loading:Je,resource:Ye,error:Qe},fetchResource:et,createResource:tt,updateResource:at,clearError:nt}=(0,u.LE)("report",(0,l.t)("report"),e),lt=()=>{nt(),ce(!0),a(),Pe([]),se({...We}),$e("active")},rt=(0,n.useMemo)((()=>(e="",t,a)=>{const n=c().encode({filter:e,page:t,page_size:a});return s.Z.get({endpoint:`/api/v1/report/related/created_by?q=${n}`}).then((e=>({data:e.json.result.map((e=>({value:e.value,label:e.text}))),totalCount:e.json.count})))}),[]),it=(0,n.useCallback)((e=>{const t=e||(null==oe?void 0:oe.database);if(!t||t.label)return null;let a;return _e.forEach((e=>{e.value!==t.value&&e.value!==t.id||(a=e)})),a}),[null==oe?void 0:oe.database,_e]),ot=(e,t)=>{se((a=>({...a,[e]:t})))},st=(0,n.useMemo)((()=>(e="",t,a)=>{const n=c().encode({filter:e,page:t,page_size:a});return s.Z.get({endpoint:`/api/v1/report/related/database?q=${n}`}).then((e=>{const t=e.json.result.map((e=>({value:e.value,label:e.text})));return ye(t),{data:t,totalCount:e.json.count}}))}),[]),dt=(null==oe?void 0:oe.database)&&!oe.database.label;(0,n.useEffect)((()=>{dt&&ot("database",it())}),[dt,it]);const ct=(0,n.useMemo)((()=>(e="",t,a)=>{const n=c().encode_uri({filter:e,page:t,page_size:a});return s.Z.get({endpoint:`/api/v1/report/related/dashboard?q=${n}`}).then((e=>{const t=e.json.result.map((e=>({value:e.value,label:e.text})));return Re(t),{data:t,totalCount:e.json.count}}))}),[]),ut=e=>{const t=e||(null==oe?void 0:oe.dashboard);if(!t||t.label)return null;let a;return Ne.forEach((e=>{e.value!==t.value&&e.value!==t.id||(a=e)})),a},ht=(0,n.useCallback)((e=>{const t=e||(null==oe?void 0:oe.chart);if(!t||t.label)return null;let a;return Se.forEach((e=>{e.value!==t.value&&e.value!==t.id||(a=e)})),a}),[Se,null==oe?void 0:oe.chart]),pt=(null==oe?void 0:oe.chart)&&!(null!=oe&&oe.chart.label);(0,n.useEffect)((()=>{pt&&ot("chart",ht())}),[ht,pt]);const mt=(0,n.useMemo)((()=>(e="",t,a)=>{const n=c().encode_uri({filter:e,page:t,page_size:a});return s.Z.get({endpoint:`/api/v1/report/related/chart?q=${n}`}).then((e=>{const t=e.json.result.map((e=>({value:e.value,label:e.text})));return xe(t),{data:t,totalCount:e.json.count}}))}),[]),vt=e=>{const{target:{type:t,value:a,name:n}}=e,l="number"===t?parseInt(a,10)||null:a;ot(n,l),"name"===n&&Tt()},gt=e=>{const{target:t}=e,a=+t.value;ot(t.name,0===a?void 0:a?Math.max(a,1):a)},bt=()=>{(()=>{var e,t;const a=[];null!=oe&&null!=(e=oe.name)&&e.length||a.push(ae.NAME_ERROR_TEXT),null!=oe&&null!=(t=oe.owners)&&t.length||a.push(ae.OWNERS_ERROR_TEXT),Le(N.bx.General,a)})(),(()=>{const e=[];"dashboard"===ue&&null!=oe&&oe.dashboard||"chart"===ue&&null!=oe&&oe.chart||e.push(ae.CONTENT_ERROR_TEXT),Le(N.bx.Content,e)})(),m||(()=>{var e,t,a;const n=[];null!=oe&&oe.database||n.push(ae.DATABASE_ERROR_TEXT),null!=oe&&null!=(e=oe.sql)&&e.length||n.push(ae.SQL_ERROR_TEXT),(Te||null!=oe&&null!=(t=oe.validator_config_json)&&t.op)&&(Te||void 0!==(null==oe||null==(a=oe.validator_config_json)?void 0:a.threshold))||n.push(ae.ALERT_CONDITION_ERROR_TEXT),Le(N.bx.Alert,n)})(),(()=>{var e;const t=[];null!=oe&&null!=(e=oe.crontab)&&e.length||t.push(ae.CRONTAB_ERROR_TEXT),null!=oe&&oe.working_timeout||t.push(ae.WORKING_TIMEOUT_ERROR_TEXT),Le(N.bx.Schedule,t)})(),(()=>{const e=(()=>{if(!Ue.length)return!1;let e=!1;return Ue.forEach((t=>{var a;t.method&&null!=(a=t.recipients)&&a.length&&(e=!0)})),e})()?[]:[ae.RECIPIENTS_ERROR_TEXT];ze&&e.push(ae.EMAIL_SUBJECT_ERROR_TEXT),Le(N.bx.Notification,e)})()};(0,n.useEffect)((()=>{if(Xe&&(null==oe||!oe.id||(null==d?void 0:d.id)!==oe.id||de&&i)){if(null!==(null==d?void 0:d.id)&&!Je&&!Qe){const e=d.id||0;et(e)}}else!Xe&&(!oe||oe.id||de&&i)&&(se({...We,owners:j?[{value:j.userId,label:`${j.firstName} ${j.lastName}`}]:[]}),Pe([{recipients:"",options:le,method:"Email"}]),$e("active"))}),[d]),(0,n.useEffect)((()=>{if(Ye){const e=(Ye.recipients||[]).map((e=>{const t="string"==typeof e.recipient_config_json?JSON.parse(e.recipient_config_json):{};return{method:e.type,recipients:t.target||e.recipient_config_json,options:le}}));Pe(e),$e(e.length===le.length?"hidden":"active"),he(Ye.chart?"chart":"dashboard"),me(Ye.report_format||D);const t="string"==typeof Ye.validator_config_json?JSON.parse(Ye.validator_config_json):Ye.validator_config_json;fe("not null"===Ye.validator_type),Ye.chart&&we(Ye.chart.viz_type),ge(Ye.force_screenshot),se({...Ye,chart:Ye.chart?ht(Ye.chart)||{value:Ye.chart.id,label:Ye.chart.slice_name}:void 0,dashboard:Ye.dashboard?ut(Ye.dashboard)||{value:Ye.dashboard.id,label:Ye.dashboard.dashboard_title}:void 0,database:Ye.database?it(Ye.database)||{value:Ye.database.id,label:Ye.database.database_name}:void 0,owners:((null==d?void 0:d.owners)||[]).map((e=>({value:e.value||e.id,label:e.label||`${e.first_name} ${e.last_name}`}))),validator_config_json:"not null"===Ye.validator_type?{op:"not null"}:t})}}),[Ye]);const Et=oe||{};(0,n.useEffect)((()=>{bt(),Tt()}),[Et.name,Et.owners,Et.database,Et.sql,Et.validator_config_json,Et.crontab,Et.working_timeout,Et.dashboard,Et.chart,ue,Ue,Te,ze]),(0,n.useEffect)((()=>{(()=>{const e=[N.bx.General,N.bx.Content,m?void 0:N.bx.Alert,N.bx.Schedule,N.bx.Notification].some((e=>e&&Ce[e].hasErrors)),t=e?(e=>{const t=[];return Object.values(e).forEach((e=>{if(e.hasErrors){const a=`${e.name}: `;t.push(a+e.errors.join(", "))}})),(0,S.BX)("div",{children:[ae.ERROR_TOOLTIP_MESSAGE,(0,S.tZ)(U,{children:t.map((e=>(0,S.tZ)("li",{children:e},e)))})]})})(Ce):"";Ae(t),ie(e)})()}),[Ce]),de&&i&&ce(!1);const Tt=()=>{var e,t;if("chart"===ue)null!=oe&&oe.name||null!=oe&&null!=(e=oe.chart)&&e.label?De(`${null==oe?void 0:oe.name}: ${(null==oe||null==(t=oe.chart)?void 0:t.label)||""}`):De("");else if("dashboard"===ue){var a,n;null!=oe&&oe.name||null!=oe&&null!=(a=oe.dashboard)&&a.label?De(`${null==oe?void 0:oe.name}: ${(null==oe||null==(n=oe.dashboard)?void 0:n.label)||""}`):De("")}else De("")},ft=e=>{qe(e)};return(0,S.tZ)(W,{className:"no-content-padding",responsive:!0,disablePrimaryButton:re,primaryTooltipMessage:Oe,onHandledPrimaryAction:()=>{var e,a,n;const r=[];Ue.forEach((e=>{e.method&&e.recipients.length&&r.push({recipient_config_json:{target:e.recipients},type:e.method})}));const i="chart"===ue&&!m,o={...oe,type:m?"Report":"Alert",force_screenshot:i||ve,validator_type:Te?"not null":"operator",validator_config_json:Te?{}:null==oe?void 0:oe.validator_config_json,chart:"chart"===ue?null==oe||null==(e=oe.chart)?void 0:e.value:null,dashboard:"dashboard"===ue?null==oe||null==(a=oe.dashboard)?void 0:a.value:null,custom_width:be?null==oe?void 0:oe.custom_width:void 0,database:null==oe||null==(n=oe.database)?void 0:n.value,owners:((null==oe?void 0:oe.owners)||[]).map((e=>e.value||e.id)),recipients:r,report_format:pe||D};if(o.recipients&&!o.recipients.length&&delete o.recipients,o.context_markdown="string",Xe){if(null!=oe&&oe.id){const e=oe.id;delete o.id,delete o.created_by,delete o.last_eval_dttm,delete o.last_state,delete o.last_value,delete o.last_value_row_json,at(e,o).then((e=>{e&&(E((0,l.t)("%s updated",o.type)),t&&t(),lt())}))}}else oe&&tt(o).then((e=>{e&&(E((0,l.t)("%s updated",o.type)),t&&t(e),lt())}))},onHide:lt,primaryButtonName:Xe?(0,l.t)("Save"):(0,l.t)("Add"),show:i,width:"500px",centered:!0,title:(0,S.tZ)("h4",{"data-test":"alert-report-modal-title",children:(()=>{let e;switch(!0){case Xe&&m:e=(0,l.t)("Edit Report");break;case Xe:e=(0,l.t)("Edit Alert");break;case m:e=(0,l.t)("Add Report");break;default:e=(0,l.t)("Add Alert")}return e})()}),children:(0,S.BX)(v.Z,{expandIconPosition:"right",defaultActiveKey:"general",accordion:!0,css:r.iv`
          border: 'none';
        `,children:[(0,S.tZ)($,{header:(0,S.tZ)(k,{title:ae.GENERAL_TITLE,subtitle:(0,l.t)("Set up basic details, such as name and description."),validateCheckStatus:!Ce[N.bx.General].hasErrors,testId:"general-information-panel"}),children:(0,S.BX)("div",{className:"header-section",children:[(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[m?(0,l.t)("Report name"):(0,l.t)("Alert name"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)("input",{type:"text",name:"name",value:oe?oe.name:"",placeholder:m?(0,l.t)("Enter report name"):(0,l.t)("Enter alert name"),onChange:vt})})]}),(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Owners"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{"data-test":"owners-select",className:"input-container",children:(0,S.tZ)(T.qb,{ariaLabel:(0,l.t)("Owners"),allowClear:!0,name:"owners",mode:"multiple",placeholder:(0,l.t)("Select owners"),value:(null==oe?void 0:oe.owners)||[],options:rt,onChange:e=>{ot("owners",e||[])}})})]}),(0,S.BX)(K,{children:[(0,S.tZ)("div",{className:"control-label",children:(0,l.t)("Description")}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)("input",{type:"text",name:"description",value:oe&&oe.description||"",placeholder:(0,l.t)("Include description to be sent with %s",Be),onChange:vt})})]}),(0,S.BX)(V,{children:[(0,S.tZ)(p.r,{checked:!!oe&&oe.active,defaultChecked:!0,onChange:e=>{ot("active",e)}}),(0,S.tZ)("div",{className:"switch-label",children:m?(0,l.t)("Report is active"):(0,l.t)("Alert is active")})]})]})},"general"),!m&&(0,S.BX)($,{header:(0,S.tZ)(k,{title:ae.ALERT_CONDITION_TITLE,subtitle:(0,l.t)("Define the database, SQL query, and triggering conditions for alert."),validateCheckStatus:!Ce[N.bx.Alert].hasErrors,testId:"alert-condition-panel"}),children:[(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Database"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)(T.qb,{ariaLabel:(0,l.t)("Database"),name:"source",placeholder:(0,l.t)("Select database"),value:null!=oe&&null!=(y=oe.database)&&y.label&&null!=oe&&null!=(C=oe.database)&&C.value?{value:oe.database.value,label:oe.database.label}:void 0,options:st,onChange:e=>{ot("database",e||[])}})})]}),(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("SQL Query"),(0,S.tZ)(Y,{tooltip:(0,l.t)('The result of this query must be a value capable of numeric interpretation e.g. 1, 1.0, or "1" (compatible with Python\'s float() function).')}),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)(f.Z,{name:"sql",language:"sql",offerEditInModal:!1,minLines:15,maxLines:15,onChange:e=>{ot("sql",e||"")},readOnly:!1,initialValue:null==Ye?void 0:Ye.sql},null==oe?void 0:oe.id)]}),(0,S.BX)("div",{className:"inline-container wrap",children:[(0,S.BX)(K,{css:H,children:[(0,S.BX)("div",{className:"control-label",css:te,children:[(0,l.t)("Trigger Alert If..."),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)(T.Ph,{ariaLabel:(0,l.t)("Condition"),onChange:e=>{var t;fe("not null"===e);const a={op:e,threshold:oe?null==(t=oe.validator_config_json)?void 0:t.threshold:void 0};ot("validator_config_json",a)},placeholder:(0,l.t)("Condition"),value:(null==oe||null==(Z=oe.validator_config_json)?void 0:Z.op)||void 0,options:z,css:te})})]}),(0,S.BX)(K,{css:H,children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Value")," ",!Te&&(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)("input",{type:"number",name:"threshold",disabled:Te,value:void 0===(null==oe||null==(O=oe.validator_config_json)?void 0:O.threshold)||Te?"":oe.validator_config_json.threshold,placeholder:(0,l.t)("Value"),onChange:e=>{var t;const{target:a}=e,n={op:oe?null==(t=oe.validator_config_json)?void 0:t.op:void 0,threshold:a.value};ot("validator_config_json",n)}})})]})]})]},"condition"),(0,S.BX)($,{header:(0,S.tZ)(k,{title:m?ae.REPORT_CONTENTS_TITLE:ae.ALERT_CONTENTS_TITLE,subtitle:(0,l.t)("Customize data source, filters, and layout."),validateCheckStatus:!Ce[N.bx.Content].hasErrors,testId:"contents-panel"}),children:[(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Content type"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)(T.Ph,{ariaLabel:(0,l.t)("Select content type"),onChange:e=>{ge(!1),he(e)},value:ue,options:F,placeholder:(0,l.t)("Select content type")})]}),(0,S.tZ)(K,{children:"chart"===ue?(0,S.BX)(S.HY,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Select chart"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)(T.qb,{ariaLabel:(0,l.t)("Chart"),name:"chart",value:null!=oe&&null!=(L=oe.chart)&&L.label&&null!=oe&&null!=(I=oe.chart)&&I.value?{value:oe.chart.value,label:oe.chart.label}:void 0,options:mt,onChange:e=>{(e=>{s.Z.get({endpoint:`/api/v1/chart/${e.value}`}).then((e=>we(e.json.result.viz_type)))})(e),ot("chart",e||void 0),ot("dashboard",null)},placeholder:(0,l.t)("Select chart to use")})]}):(0,S.BX)(S.HY,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Select dashboard"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)(T.qb,{ariaLabel:(0,l.t)("Dashboard"),name:"dashboard",value:null!=oe&&null!=(w=oe.dashboard)&&w.label&&null!=oe&&null!=(X=oe.dashboard)&&X.value?{value:oe.dashboard.value,label:oe.dashboard.label}:void 0,options:ct,onChange:e=>{ot("dashboard",e||void 0),ot("chart",null)},placeholder:(0,l.t)("Select dashboard to use")})]})}),(0,S.tZ)(K,{css:["PDF","TEXT","CSV"].includes(pe)&&H,children:ke&&(0,S.BX)(S.HY,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Content format"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)(T.Ph,{ariaLabel:(0,l.t)("Select format"),onChange:e=>{me(e)},value:pe,options:"dashboard"===ue?["pdf","png"].map((e=>G[e])):P.includes(Ie)?Object.values(G):["pdf","png","csv"].map((e=>G[e])),placeholder:(0,l.t)("Select format")})]})}),be&&(0,S.BX)(K,{css:!m&&"chart"===ue&&H,children:[(0,S.tZ)("div",{className:"control-label",children:(0,l.t)("Screenshot width")}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)(h.Rn,{type:"number",name:"custom_width",value:(null==oe?void 0:oe.custom_width)||void 0,min:600,max:2400,placeholder:(0,l.t)("Input custom width in pixels"),onChange:e=>{ot("custom_width",e)}})})]}),(m||"dashboard"===ue)&&(0,S.tZ)("div",{className:"inline-container",children:(0,S.tZ)(J,{"data-test":"bypass-cache",className:"checkbox",checked:ve,onChange:e=>{ge(e.target.checked)},children:(0,l.t)("Ignore cache when generating report")})})]},"contents"),(0,S.BX)($,{header:(0,S.tZ)(k,{title:ae.SCHEDULE_TITLE,subtitle:(0,l.t)("Define delivery schedule, timezone, and frequency settings."),validateCheckStatus:!Ce[N.bx.Schedule].hasErrors,testId:"schedule-panel"}),children:[(0,S.tZ)(A,{value:(null==oe?void 0:oe.crontab)||"",onChange:e=>ot("crontab",e)}),(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Timezone")," ",(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)(g.Z,{onTimezoneChange:e=>{ot("timezone",e)},timezone:null==oe?void 0:oe.timezone,minWidth:"100%"})]}),(0,S.BX)(K,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Log retention"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)(T.Ph,{ariaLabel:(0,l.t)("Log retention"),placeholder:(0,l.t)("Log retention"),onChange:e=>{ot("log_retention",e)},value:null==oe?void 0:oe.log_retention,options:q,sortComparator:(0,b.mj)("value")})})]}),(0,S.tZ)(K,{css:H,children:m?(0,S.BX)(S.HY,{children:[(0,S.BX)("div",{className:"control-label",children:[(0,l.t)("Working timeout"),(0,S.tZ)("span",{className:"required",children:"*"})]}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)(x,{min:1,name:"working_timeout",value:(null==oe?void 0:oe.working_timeout)||"",placeholder:(0,l.t)("Time in seconds"),onChange:gt,timeUnit:(0,l.t)("seconds")})})]}):(0,S.BX)(S.HY,{children:[(0,S.tZ)("div",{className:"control-label",children:(0,l.t)("Grace period")}),(0,S.tZ)("div",{className:"input-container",children:(0,S.tZ)(x,{min:1,name:"grace_period",value:(null==oe?void 0:oe.grace_period)||"",placeholder:(0,l.t)("Time in seconds"),onChange:gt,timeUnit:(0,l.t)("seconds")})})]})})]},"schedule"),(0,S.BX)($,{header:(0,S.tZ)(k,{title:ae.NOTIFICATION_TITLE,subtitle:(0,l.t)("Choose notification method and recipients."),validateCheckStatus:!Ce[N.bx.Notification].hasErrors,testId:"notification-method-panel"}),children:[Ue.map(((e,t)=>(0,S.tZ)(ee,{children:(0,S.tZ)(B,{setting:e,index:t,onUpdate:Ve,onRemove:Ke,onInputChange:vt,email_subject:(null==oe?void 0:oe.email_subject)||"",defaultSubject:Me||"",setErrorSubject:ft},`NotificationMethod-${t}`)}))),le.length>Ue.length&&(0,S.tZ)(ne,{"data-test":"notification-add",status:je,onClick:()=>{Pe([...Ue,{recipients:"",options:le.filter((e=>!Ue.reduce(((t,a)=>t||e===a.method),!1)))}]),$e(Ue.length===le.length?"hidden":"disabled")}})]},"notification")]})})}))},690335:(e,t,a)=>{var n,l,r;a.d(t,{Z9:()=>n,bx:()=>r,ud:()=>l}),function(e){e.Success="Success",e.Working="Working",e.Error="Error",e.Noop="Not triggered",e.Grace="On Grace"}(n||(n={})),function(e){e.Email="Email",e.Slack="Slack"}(l||(l={})),function(e){e.General="generalSection",e.Content="contentSection",e.Alert="alertConditionSection",e.Schedule="scheduleSection",e.Notification="notificationSection"}(r||(r={}))}}]);
//# sourceMappingURL=47c397547303c6cd0c08.chunk.js.map