"use strict";(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[6387],{786387:(e,t,r)=>{r.r(t),r.d(t,{default:()=>w});var o=r(441609),i=r.n(o),n=r(667294),s=r(751995),l=r(221283),c=r(355786),a=r(706882),d=r(211965),u=r(61988),f=r(51776),h=r(189201),p=r(23279),g=r.n(p);const m=e=>{const t=(0,n.useRef)(null),r=(0,n.useRef)(null),[o,i]=(0,n.useState)(!1);return(0,n.useEffect)((()=>{let o;const n=t.current,s=r.current;if(n&&s){const t=Array.from(n.children);o=new ResizeObserver(g()((()=>{t.reduce(((e,t)=>{var r,o;return e+(null!=(r=null==(o=t.firstElementChild)?void 0:o.scrollWidth)?r:0)}),0)+e*Math.max(t.length-1,0)>s.clientWidth?i(!0):i(!1)}),500)),o.observe(document.body),t.forEach((e=>{o.observe(e)}))}return()=>{var e;return null==(e=o)?void 0:e.disconnect()}}),[e]),{isOverflowing:o,symbolContainerRef:t,wrapperRef:r}};var b=r(135944);const v=s.iK.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  width: 100%;
  overflow: auto;
`,x=s.iK.div`
  ${({theme:e,subheaderFontSize:t})=>`\n    font-weight: ${e.typography.weights.light};\n    display: flex;\n    justify-content: center;\n    font-size: ${t||20}px;\n    flex: 1 1 0px;\n  `}
`,y=s.iK.span`
  ${({theme:e,backgroundColor:t,textColor:r})=>`\n    background-color: ${t};\n    color: ${r};\n    padding: ${e.gridUnit}px ${2*e.gridUnit}px;\n    border-radius: ${2*e.gridUnit}px;\n    margin-right: ${e.gridUnit}px;\n  `}
`;function w(e){const{height:t,width:r,bigNumber:o,prevNumber:p,valueDifference:g,percentDifferenceFormattedString:w,headerFontSize:$,subheaderFontSize:C,comparisonColorEnabled:R,comparisonColorScheme:k,percentDifferenceNumber:S,currentTimeRangeFilter:z,startDateOffset:F,shift:T}=e,[U,Z]=(0,n.useState)("");(0,n.useEffect)((()=>{if(z&&(T||F)){if(!i()(T)||F){const e=(0,l.dS)({timeRangeFilter:z,shifts:(0,c.Z)(T),startDate:F||""}),t=(0,a.z1)(z.comparator,z.subject,e||[]);Promise.resolve(t).then((e=>{const t=(0,c.Z)(e.value).flat()[0].split("vs\n");Z(t.length>1?t[1].trim():t[0])}))}}else Z("")}),[z,T,F]);const D=(0,s.Fg)(),j=5*D.gridUnit,E=d.iv`
    font-family: ${D.typography.families.sansSerif};
    display: flex;
    justify-content: center;
    align-items: center;
    height: ${t}px;
    width: ${r}px;
    overflow: auto;
  `,O=d.iv`
    font-size: ${$||60}px;
    font-weight: ${D.typography.weights.normal};
    text-align: center;
    margin-bottom: ${4*D.gridUnit}px;
  `,B=d.iv`
    color: ${R&&0!==S?S>0?k===h.v.Green?D.colors.success.base:D.colors.error.base:k===h.v.Red?D.colors.success.base:D.colors.error.base:D.colors.grayscale.base};
    margin-left: ${D.gridUnit}px;
  `,K=D.colors.grayscale.light4,M=D.colors.grayscale.base,{backgroundColor:N,textColor:X}=(0,n.useMemo)((()=>{let e=K,t=M;if(R&&0!==S){const r=S>0&&k===h.v.Green||S<0&&k===h.v.Red;e=r?D.colors.success.light2:D.colors.error.light2,t=r?D.colors.success.base:D.colors.error.base}return{backgroundColor:e,textColor:t}}),[D,k,R,S]),G=(0,n.useMemo)((()=>[{symbol:"#",value:p,tooltipText:(0,u.t)("Data for %s",U||"previous range")},{symbol:"△",value:g,tooltipText:(0,u.t)("Value difference between the time periods")},{symbol:"%",value:w,tooltipText:(0,u.t)("Percentage difference between the time periods")}]),[U,p,g,w]),{isOverflowing:P,symbolContainerRef:W,wrapperRef:A}=m(j);return(0,b.tZ)("div",{css:E,ref:A,children:(0,b.BX)(v,{css:P&&d.iv`
            width: fit-content;
            margin: auto;
            align-items: flex-start;
          `,children:[(0,b.BX)("div",{css:O,children:[o,0!==S&&(0,b.tZ)("span",{css:B,children:S>0?"↑":"↓"})]}),(0,b.tZ)("div",{css:[d.iv`
              display: flex;
              justify-content: space-around;
              gap: ${j}px;
              min-width: 0;
              flex-shrink: 1;
            `,P?d.iv`
                  flex-direction: column;
                  align-items: flex-start;
                  width: fit-content;
                `:d.iv`
                  align-items: center;
                  width: 100%;
                `,"",""],ref:W,children:G.map(((e,t)=>(0,b.tZ)(x,{subheaderFontSize:C,children:(0,b.BX)(f.u,{id:"tooltip",placement:"top",title:e.tooltipText,children:[(0,b.tZ)(y,{backgroundColor:t>0?N:K,textColor:t>0?X:M,children:e.symbol}),e.value]})},`comparison-symbol-${e.symbol}`)))})]})})}}}]);
//# sourceMappingURL=f326600dee5f0467baa8.chunk.js.map