"use strict";(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[8438],{762529:(e,t,n)=>{n.d(t,{Z:()=>v});var a=n(204942),i=n(671002),r=n(487462),l=n(667294),o=n(765995),s=n(693967),c=n.n(s),d=n(529439),u=n(65632),h=n(796159);function p(e){return e?e.toString().split("").reverse().map((function(e){var t=Number(e);return isNaN(t)?e:t})):[]}const m=function(e){var t=e.prefixCls,n=e.count,a=e.className,i=e.style,o=e.title,s=e.show,m=e.component,g=void 0===m?"sup":m,b=e.children,f=e.onAnimated,v=void 0===f?function(){}:f,y=function(e,t){var n={};for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&t.indexOf(a)<0&&(n[a]=e[a]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var i=0;for(a=Object.getOwnPropertySymbols(e);i<a.length;i++)t.indexOf(a[i])<0&&Object.prototype.propertyIsEnumerable.call(e,a[i])&&(n[a[i]]=e[a[i]])}return n}(e,["prefixCls","count","className","style","title","show","component","children","onAnimated"]),x=(0,l.useState)(!0),w=(0,d.Z)(x,2),Z=w[0],$=w[1],S=(0,l.useState)(n),C=(0,d.Z)(S,2),U=C[0],z=C[1],T=(0,l.useState)(n),_=(0,d.Z)(T,2),E=_[0],k=_[1],N=(0,l.useState)(n),P=(0,d.Z)(N,2),I=P[0],K=P[1],M=(0,l.useContext(u.E_).getPrefixCls)("scroll-number",t);E!==n&&($(!0),k(n)),l.useEffect((function(){var e;return K(U),Z&&(e=setTimeout((function(){$(!1),z(n),v()}))),function(){e&&clearTimeout(e)}}),[Z,n,v]);var O=(0,r.Z)((0,r.Z)({},y),{"data-show":s,style:i,className:c()(M,a),title:o}),B=U&&Number(U)%1==0?p(U).map((function(e,t){return function(e,t){if("number"==typeof e){var n=function(e,t){var n=Math.abs(Number(U)),a=Math.abs(Number(I)),i=Math.abs(p(U)[t]),r=Math.abs(p(a)[t]);return Z?10+e:n>a?i>=r?10+e:20+e:i<=r?10+e:e}(e,t),a=Z||void 0===p(I)[t];return l.createElement("span",{className:"".concat(M,"-only"),style:{transition:a?"none":void 0,msTransform:"translateY(".concat(100*-n,"%)"),WebkitTransform:"translateY(".concat(100*-n,"%)"),transform:"translateY(".concat(100*-n,"%)")},key:t},function(e,t){for(var n=[],a=0;a<30;a++)n.push(l.createElement("p",{key:a.toString(),className:c()(t,{current:e===a})},a%10));return n}(n,"".concat(M,"-only-unit")))}return l.createElement("span",{key:"symbol",className:"".concat(M,"-symbol")},e)}(e,t)})).reverse():U;return i&&i.borderColor&&(O.style=(0,r.Z)((0,r.Z)({},i),{boxShadow:"0 0 0 1px ".concat(i.borderColor," inset")})),b?(0,h.Tm)(b,(function(e){return{className:c()("".concat(M,"-custom-component"),null==e?void 0:e.className)}})):l.createElement(g,O,B)};var g=n(798787);function b(e){return-1!==g.Y.indexOf(e)}var f=function(e){var t,n,s=e.prefixCls,d=e.scrollNumberPrefixCls,p=e.children,g=e.status,f=e.text,v=e.color,y=e.count,x=void 0===y?null:y,w=e.overflowCount,Z=void 0===w?99:w,$=e.dot,S=void 0!==$&&$,C=e.size,U=void 0===C?"default":C,z=e.title,T=e.offset,_=e.style,E=e.className,k=e.showZero,N=void 0!==k&&k,P=function(e,t){var n={};for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&t.indexOf(a)<0&&(n[a]=e[a]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var i=0;for(a=Object.getOwnPropertySymbols(e);i<a.length;i++)t.indexOf(a[i])<0&&Object.prototype.propertyIsEnumerable.call(e,a[i])&&(n[a[i]]=e[a[i]])}return n}(e,["prefixCls","scrollNumberPrefixCls","children","status","text","color","count","overflowCount","dot","size","title","offset","style","className","showZero"]),I=l.useContext(u.E_),K=I.getPrefixCls,M=I.direction,O=K("badge",s),B=x>Z?"".concat(Z,"+"):x,X=null!=g||null!=v,R="0"===B||0===B,D=S&&!R||X,j=D?"":B,V=(0,l.useMemo)((function(){return(null==j||""===j||R&&!N)&&!D}),[j,R,N,D]),A=(0,l.useRef)(j);V||(A.current=j);var H=A.current,L=(0,l.useRef)(D);V||(L.current=D);var Y=(0,l.useMemo)((function(){if(!T)return(0,r.Z)({},_);var e={marginTop:T[1]};return"rtl"===M?e.left=parseInt(T[0],10):e.right=-parseInt(T[0],10),(0,r.Z)((0,r.Z)({},e),_)}),[M,T,_]),W=null!=z?z:"string"==typeof x||"number"==typeof x?x:void 0,F=V||!f?null:l.createElement("span",{className:"".concat(O,"-status-text")},f),q=x&&"object"===(0,i.Z)(x)?(0,h.Tm)(x,(function(e){return{style:(0,r.Z)((0,r.Z)({},Y),e.style)}})):void 0,G=c()((t={},(0,a.Z)(t,"".concat(O,"-status-dot"),X),(0,a.Z)(t,"".concat(O,"-status-").concat(g),!!g),(0,a.Z)(t,"".concat(O,"-status-").concat(v),b(v)),t)),Q={};v&&!b(v)&&(Q.background=v);var J=c()(O,(n={},(0,a.Z)(n,"".concat(O,"-status"),X),(0,a.Z)(n,"".concat(O,"-not-a-wrapper"),!p),(0,a.Z)(n,"".concat(O,"-rtl"),"rtl"===M),n),E);if(!p&&X){var ee=Y.color;return l.createElement("span",(0,r.Z)({},P,{className:J,style:Y}),l.createElement("span",{className:G,style:Q}),l.createElement("span",{style:{color:ee},className:"".concat(O,"-status-text")},f))}return l.createElement("span",(0,r.Z)({},P,{className:J}),p,l.createElement(o.default,{visible:!V,motionName:"".concat(O,"-zoom"),motionAppear:!1},(function(e){var t,n=e.className,i=K("scroll-number",d),o=L.current,s=c()((t={},(0,a.Z)(t,"".concat(O,"-dot"),o),(0,a.Z)(t,"".concat(O,"-count"),!o),(0,a.Z)(t,"".concat(O,"-count-sm"),"small"===U),(0,a.Z)(t,"".concat(O,"-multiple-words"),!o&&H&&(null==H?void 0:H.toString().length)>1),(0,a.Z)(t,"".concat(O,"-status-").concat(g),!!g),(0,a.Z)(t,"".concat(O,"-status-").concat(v),b(v)),t)),u=(0,r.Z)({},Y);return v&&!b(v)&&((u=u||{}).background=v),l.createElement(m,{prefixCls:i,show:!V,className:c()(n,s),count:H,title:W,style:u,key:"scrollNumber"},q)})),F)};f.Ribbon=function(e){var t,n=e.className,i=e.prefixCls,o=e.style,s=e.color,d=e.children,h=e.text,p=e.placement,m=void 0===p?"end":p,g=l.useContext(u.E_),f=g.getPrefixCls,v=g.direction,y=f("ribbon",i),x=b(s),w=c()(y,"".concat(y,"-placement-").concat(m),(t={},(0,a.Z)(t,"".concat(y,"-rtl"),"rtl"===v),(0,a.Z)(t,"".concat(y,"-color-").concat(s),x),t),n),Z={},$={};return s&&!x&&(Z.background=s,$.color=s),l.createElement("div",{className:"".concat(y,"-wrapper")},d,l.createElement("div",{className:w,style:(0,r.Z)((0,r.Z)({},Z),o)},l.createElement("span",{className:"".concat(y,"-text")},h),l.createElement("div",{className:"".concat(y,"-corner"),style:$})))};const v=f},751794:(e,t,n)=>{n.d(t,{Z:()=>i});var a=n(667294);const i=()=>{const[e,t]=(0,a.useState)(0),[n,i]=(0,a.useState)(!1),r=(0,a.useRef)(null),l=(0,a.useRef)(null);return(0,a.useLayoutEffect)((()=>{var e;const n=()=>{const e=r.current;if(!e)return;const n=l.current,{scrollWidth:a,clientWidth:o,childNodes:s}=e;if(a>o){const e=6,a=(null==n?void 0:n.offsetWidth)||0,r=o-e,l=s.length;let c=0,d=0;for(let e=0;e<l;e+=1)r-c-a<=0&&(d+=1),c+=s[e].offsetWidth;l>1&&d?(i(!0),t(d)):(i(!1),t(1))}else i(!1),t(0)},a=new ResizeObserver(n),o=null==(e=r.current)?void 0:e.parentElement;return o&&a.observe(o),n(),()=>{a.disconnect()}}),[l.current]),[r,l,e,n]}},852564:(e,t,n)=>{n.d(t,{u:()=>w});var a=n(211965),i=n(751995),r=n(61988),l=n(104715),o=n(667294),s=n(358593),c=n(899612),d=n(135944);const u=e=>a.iv`
  display: flex;
  font-size: ${e.typography.sizes.xl}px;
  font-weight: ${e.typography.weights.bold};
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;

  & .dynamic-title,
  & .dynamic-title-input {
    display: inline-block;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  & .dynamic-title {
    cursor: default;
  }
  & .dynamic-title-input {
    border: none;
    padding: 0;
    outline: none;

    &::placeholder {
      color: ${e.colors.grayscale.light1};
    }
  }

  & .input-sizer {
    position: absolute;
    left: -9999px;
    display: inline-block;
  }
`,h=({title:e,placeholder:t,onSave:n,canEdit:i,label:l})=>{const[h,p]=(0,o.useState)(!1),[m,g]=(0,o.useState)(e||""),b=(0,o.useRef)(null),[f,v]=(0,o.useState)(!1),{width:y,ref:x}=(0,c.NB)(),{width:w,ref:Z}=(0,c.NB)({refreshMode:"debounce"});(0,o.useEffect)((()=>{g(e)}),[e]),(0,o.useEffect)((()=>{if(h&&null!=b&&b.current&&(b.current.focus(),b.current.setSelectionRange)){const{length:e}=b.current.value;b.current.setSelectionRange(e,e),b.current.scrollLeft=b.current.scrollWidth}}),[h]),(0,o.useLayoutEffect)((()=>{null!=x&&x.current&&(x.current.textContent=m||t)}),[m,t,x]),(0,o.useEffect)((()=>{b.current&&b.current.scrollWidth>b.current.clientWidth?v(!0):v(!1)}),[y,w]);const $=(0,o.useCallback)((()=>{i&&!h&&p(!0)}),[i,h]),S=(0,o.useCallback)((()=>{if(!i)return;const t=m.trim();g(t),e!==t&&n(t),p(!1)}),[i,m,n,e]),C=(0,o.useCallback)((e=>{i&&h&&g(e.target.value)}),[i,h]),U=(0,o.useCallback)((e=>{var t;i&&"Enter"===e.key&&(e.preventDefault(),null==(t=b.current)||t.blur())}),[i]);return(0,d.BX)("div",{css:u,ref:Z,children:[(0,d.tZ)(s.u,{id:"title-tooltip",title:f&&m&&!h?m:null,children:i?(0,d.tZ)("input",{"data-test":"editable-title-input",className:"dynamic-title-input","aria-label":null!=l?l:(0,r.t)("Title"),ref:b,onChange:C,onBlur:S,onClick:$,onKeyPress:U,placeholder:t,value:m,css:a.iv`
              cursor: ${h?"text":"pointer"};

              ${y&&y>0&&a.iv`
                width: ${y+1}px;
              `}
            `}):(0,d.tZ)("span",{className:"dynamic-title","aria-label":null!=l?l:(0,r.t)("Title"),ref:b,"data-test":"editable-title",children:m})}),(0,d.tZ)("span",{ref:x,className:"input-sizer","aria-hidden":!0,tabIndex:-1})]})};var p=n(679789),m=n(236674),g=n(313322),b=n(835932);const f=e=>a.iv`
  width: ${8*e.gridUnit}px;
  height: ${8*e.gridUnit}px;
  padding: 0;
  border: 1px solid ${e.colors.primary.dark2};

  &.ant-btn > span.anticon {
    line-height: 0;
    transition: inherit;
  }

  &:hover:not(:focus) > span.anticon {
    color: ${e.colors.primary.light1};
  }
  &:focus-visible {
    outline: 2px solid ${e.colors.primary.dark2};
  }
`,v=e=>a.iv`
  display: flex;
  flex-direction: row;
  align-items: center;
  flex-wrap: nowrap;
  justify-content: space-between;
  background-color: ${e.colors.grayscale.light5};
  height: ${16*e.gridUnit}px;
  padding: 0 ${4*e.gridUnit}px;

  .editable-title {
    overflow: hidden;

    & > input[type='button'],
    & > span {
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 100%;
      white-space: nowrap;
    }
  }

  span[role='button'] {
    display: flex;
    height: 100%;
  }

  .title-panel {
    display: flex;
    align-items: center;
    min-width: 0;
    margin-right: ${12*e.gridUnit}px;
  }

  .right-button-panel {
    display: flex;
    align-items: center;
  }
`,y=e=>a.iv`
  display: flex;
  align-items: center;
  padding-left: ${2*e.gridUnit}px;

  & .fave-unfave-icon {
    padding: 0 ${e.gridUnit}px;

    &:first-of-type {
      padding-left: 0;
    }
  }
`,x=e=>a.iv`
  margin-left: ${2*e.gridUnit}px;
`,w=({editableTitleProps:e,showTitlePanelItems:t,certificatiedBadgeProps:n,showFaveStar:a,faveStarProps:o,titlePanelAdditionalItems:s,rightPanelAdditionalItems:c,additionalActionsMenu:u,menuDropdownProps:w,showMenuDropdown:Z=!0,tooltipProps:$})=>{const S=(0,i.Fg)();return(0,d.BX)("div",{css:v,className:"header-with-actions",children:[(0,d.BX)("div",{className:"title-panel",children:[(0,d.tZ)(h,{...e}),t&&(0,d.BX)("div",{css:y,children:[(null==n?void 0:n.certifiedBy)&&(0,d.tZ)(p.Z,{...n}),a&&(0,d.tZ)(m.Z,{...o}),s]})]}),(0,d.BX)("div",{className:"right-button-panel",children:[c,(0,d.tZ)("div",{css:x,children:Z&&(0,d.tZ)(l.Gj,{trigger:["click"],overlay:u,...w,children:(0,d.tZ)(b.Z,{css:f,buttonStyle:"tertiary","aria-label":(0,r.t)("Menu actions trigger"),tooltip:null==$?void 0:$.text,placement:null==$?void 0:$.placement,"data-test":"actions-trigger",children:(0,d.tZ)(g.Z.MoreHoriz,{iconColor:S.colors.primary.dark2,iconSize:"l"})})})})]})]})}},280663:(e,t,n)=>{n.d(t,{Z:()=>c});var a=n(929119),i=n(751995),r=n(667294),l=n(961337),o=n(135944);const s=i.iK.div`
  position: absolute;
  height: 100%;

  :hover .sidebar-resizer::after {
    background-color: ${({theme:e})=>e.colors.primary.base};
  }

  .sidebar-resizer {
    // @z-index-above-sticky-header (100) + 1 = 101
    z-index: 101;
  }

  .sidebar-resizer::after {
    display: block;
    content: '';
    width: 1px;
    height: 100%;
    margin: 0 auto;
  }
`,c=({id:e,initialWidth:t,minWidth:n,maxWidth:i,enable:c,children:d})=>{const[u,h]=function(e,t){const n=(0,r.useRef)(),[a,i]=(0,r.useState)(t);return(0,r.useEffect)((()=>{var t;n.current=null!=(t=n.current)?t:(0,l.rV)(l.dR.CommonResizableSidebarWidths,{}),n.current[e]&&i(n.current[e])}),[e]),[a,function(t){i(t),(0,l.LS)(l.dR.CommonResizableSidebarWidths,{...n.current,[e]:t})}]}(e,t);return(0,o.BX)(o.HY,{children:[(0,o.tZ)(s,{children:(0,o.tZ)(a.e,{enable:{right:c},handleClasses:{right:"sidebar-resizer"},size:{width:u,height:"100%"},minWidth:n,maxWidth:i,onResizeStop:(e,t,n,a)=>h(u+a.width)})}),d(u)]})}},486057:(e,t,n)=>{n.d(t,{Z:()=>c});var a=n(211965),i=n(751995),r=n(178186),l=n(313322),o=n(358593),s=n(135944);const c=function({warningMarkdown:e,size:t,marginRight:n}){const c=(0,i.Fg)();return(0,s.tZ)(o.u,{id:"warning-tooltip",title:(0,s.tZ)(r.Z,{source:e}),children:(0,s.tZ)(l.Z.AlertSolid,{iconColor:c.colors.alert.base,iconSize:t,css:(0,a.iv)({marginRight:null!=n?n:2*c.gridUnit},"","")})})}},903720:(e,t,n)=>{n.r(t),n.d(t,{datasetReducer:()=>ut,default:()=>pt});var a=n(667294),i=n(616550),r=n(431069),l=n(61988),o=n(68492),s=n(115926),c=n.n(s),d=n(672570);const u=(e,t)=>{const[n,i]=(0,a.useState)([]),s=t?encodeURIComponent(t):void 0,u=(0,a.useCallback)((async e=>{let t,n=[],a=0;for(;void 0===t||n.length<t;){const i=c().encode_uri({filters:e,page:a});try{const e=await r.Z.get({endpoint:`/api/v1/dataset/?q=${i}`});({count:t}=e.json);const{json:{result:l}}=e;n=[...n,...l],a+=1}catch(e){(0,d.Gb)((0,l.t)("There was an error fetching dataset")),o.Z.error((0,l.t)("There was an error fetching dataset"),e)}}i(n)}),[]);(0,a.useEffect)((()=>{const n=[{col:"database",opr:"rel_o_m",value:null==e?void 0:e.id},{col:"schema",opr:"eq",value:s},{col:"sql",opr:"dataset_is_null_or_empty",value:!0}];t&&u(n)}),[null==e?void 0:e.id,t,s,u]);const h=(0,a.useMemo)((()=>null==n?void 0:n.map((e=>e.table_name))),[n]);return{datasets:n,datasetNames:h}};var h,p=n(852564),m=n(835932),g=n(313322),b=n(683862);!function(e){e[e.SelectDatabase=0]="SelectDatabase",e[e.SelectCatalog=1]="SelectCatalog",e[e.SelectSchema=2]="SelectSchema",e[e.SelectTable=3]="SelectTable",e[e.ChangeDataset=4]="ChangeDataset"}(h||(h={}));var f=n(751995),v=n(211965);const y=f.iK.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  background-color: ${({theme:e})=>e.colors.grayscale.light5};
`,x=f.iK.div`
  width: ${({theme:e,width:t})=>null!=t?t:80*e.gridUnit}px;
  max-width: ${({theme:e,width:t})=>null!=t?t:80*e.gridUnit}px;
  flex-direction: column;
  flex: 1 0 auto;
`,w=f.iK.div`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
`,Z=f.iK.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: row;
`,$=(0,f.iK)(Z)`
  flex: 1 0 auto;
  position: relative;
`,S=(0,f.iK)(Z)`
  flex: 1 0 auto;
  height: auto;
`,C=(0,f.iK)(Z)`
  flex: 0 0 auto;
  height: ${({theme:e})=>16*e.gridUnit}px;
  z-index: 0;
`,U=f.iK.div`
  ${({theme:e})=>`\n  flex: 0 0 auto;\n  height: ${16*e.gridUnit}px;\n  border-bottom: 2px solid ${e.colors.grayscale.light2};\n\n  .header-with-actions {\n    height: ${15.5*e.gridUnit}px;\n  }\n  `}
`,z=f.iK.div`
  ${({theme:e})=>`\n  margin: ${4*e.gridUnit}px;\n  font-size: ${e.typography.sizes.xl}px;\n  font-weight: ${e.typography.weights.bold};\n  `}
`,T=f.iK.div`
  ${({theme:e})=>`\n  height: 100%;\n  border-right: 1px solid ${e.colors.grayscale.light2};\n  `}
`,_=f.iK.div`
  width: 100%;
  position: relative;
`,E=f.iK.div`
  ${({theme:e})=>`\n  border-left: 1px solid ${e.colors.grayscale.light2};\n  color: ${e.colors.success.base};\n  `}
`,k=f.iK.div`
  ${({theme:e})=>`\n  height: ${16*e.gridUnit}px;\n  width: 100%;\n  border-top: 1px solid ${e.colors.grayscale.light2};\n  border-bottom: 1px solid ${e.colors.grayscale.light2};\n  color: ${e.colors.info.base};\n  border-top: ${e.gridUnit/4}px solid\n    ${e.colors.grayscale.light2};\n  padding: ${4*e.gridUnit}px;\n  display: flex;\n  justify-content: flex-end;\n  background-color: ${e.colors.grayscale.light5};\n  z-index: ${e.zIndex.max}\n  `}
`,N=f.iK.div`
  .ant-btn {
    span {
      margin-right: 0;
    }

    &:disabled {
      svg {
        color: ${({theme:e})=>e.colors.grayscale.light1};
      }
    }
  }
`,P=e=>v.iv`
  width: ${21.5*e.gridUnit}px;

  &:disabled {
    background-color: ${e.colors.grayscale.light3};
    color: ${e.colors.grayscale.light1};
  }
`;var I=n(135944);const K=(0,l.t)("New dataset"),M={text:(0,l.t)("Select a database table and create dataset"),placement:"bottomRight"},O=()=>(0,I.BX)(m.Z,{buttonStyle:"primary",tooltip:null==M?void 0:M.text,placement:null==M?void 0:M.placement,disabled:!0,css:P,children:[(0,I.tZ)(g.Z.Save,{iconSize:"m"}),(0,l.t)("Save")]}),B=()=>(0,I.BX)(b.Menu,{children:[(0,I.tZ)(b.Menu.Item,{children:(0,l.t)("Settings")}),(0,I.tZ)(b.Menu.Item,{children:(0,l.t)("Delete")})]});function X({setDataset:e,title:t=K,editing:n=!1}){const a={title:null!=t?t:K,placeholder:K,onSave:t=>{e({type:h.ChangeDataset,payload:{name:"dataset_name",value:t}})},canEdit:!1,label:(0,l.t)("dataset name")};return(0,I.tZ)(N,{children:n?(0,I.tZ)(p.u,{editableTitleProps:a,showTitlePanelItems:!1,showFaveStar:!1,faveStarProps:{itemId:1,saveFaveStar:()=>{}},titlePanelAdditionalItems:(0,I.tZ)(I.HY,{}),rightPanelAdditionalItems:O(),additionalActionsMenu:B(),menuDropdownProps:{disabled:!0},tooltipProps:M}):(0,I.tZ)(z,{children:t||K})})}var R,D,j=n(782607),V=n(171262),A=n(473727),H=n(355786),L=n(493197),Y=n(94301);function W(){return W=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var a in n)Object.prototype.hasOwnProperty.call(n,a)&&(e[a]=n[a])}return e},W.apply(this,arguments)}const F=({title:e,titleId:t,...n},i)=>a.createElement("svg",W({xmlns:"http://www.w3.org/2000/svg",width:160,height:166,fill:"none",ref:i,"aria-labelledby":t},n),e?a.createElement("title",{id:t},e):null,R||(R=a.createElement("path",{fill:"#FAFAFA",fillRule:"evenodd",d:"M123.638 8a.5.5 0 0 0-.5.5V158h28.758V8.5a.5.5 0 0 0-.5-.5zM84.793 40.643a.5.5 0 0 1 .5-.5h27.759a.5.5 0 0 1 .5.5V158H84.793zM46.95 72.285a.5.5 0 0 0-.5.5V158h28.758V72.785a.5.5 0 0 0-.5-.5zM8.604 93.715a.5.5 0 0 0-.5.5V158h28.758V94.215a.5.5 0 0 0-.5-.5z",clipRule:"evenodd"})),D||(D=a.createElement("path",{fill:"#D9D9D9",d:"M123.138 158h-.5v.5h.5zm28.758 0v.5h.5v-.5zm-38.344 0v.5h.5v-.5zm-28.759 0h-.5v.5h.5zm-38.344-.001h-.5v.5h.5zm28.758 0v.5h.5v-.5zM8.104 158h-.5v.5h.5zm28.758 0v.5h.5v-.5zM123.639 8.5v-1a1 1 0 0 0-1 1zm0 149.5V8.5h-1V158zm28.258-.5h-28.758v1h28.758zm-.5-149V158h1V8.5zm0 0h1a1 1 0 0 0-1-1zm-27.758 0h27.758v-1h-27.758zM85.293 39.643a1 1 0 0 0-1 1h1zm27.759 0H85.293v1h27.759zm1 1a1 1 0 0 0-1-1v1zm0 117.357V40.643h-1V158zm-29.259.5h28.759v-1H84.793zm-.5-117.857V158h1V40.643zM46.95 72.785v-1a1 1 0 0 0-1 1zm0 85.214V72.785h-1V158zm28.258-.5H46.45v1h28.758zm-.5-84.714V158h1V72.785zm0 0h1a1 1 0 0 0-1-1zm-27.758 0h27.758v-1H46.95zM8.604 94.215v-1a1 1 0 0 0-1 1zm0 63.785V94.215h-1V158zm28.258-.5H8.104v1h28.758zm-.5-63.285V158h1V94.215zm0 0h1a1 1 0 0 0-1-1zm-27.758 0h27.758v-1H8.604z"}))),q=(0,a.forwardRef)(F);var G=n(414114),Q=n(34858),J=n(593139),ee=n(730381),te=n.n(ee),ne=n(751794),ae=n(358593);const ie=f.iK.div`
  & > span {
    width: 100%;
    display: flex;

    .ant-tooltip-open {
      display: inline;
    }
  }
`,re=f.iK.span`
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: inline-block;
  width: 100%;
  vertical-align: bottom;
`,le=f.iK.span`
  &:not(:last-child)::after {
    content: ', ';
  }
`,oe=f.iK.div`
  .link {
    color: ${({theme:e})=>e.colors.grayscale.light5};
    display: block;
    text-decoration: underline;
  }
`,se=f.iK.span`
  ${({theme:e})=>`\n  cursor: pointer;\n  color: ${e.colors.primary.dark1};\n  font-weight: ${e.typography.weights.normal};\n  `}
`;function ce({items:e,renderVisibleItem:t=(e=>e),renderTooltipItem:n=(e=>e),getKey:i=(e=>e),maxLinks:r=20}){const[o,s,c,d]=(0,ne.Z)(),u=(0,a.useMemo)((()=>e.length>r?e.length-r:void 0),[e,r]),h=(0,a.useMemo)((()=>(0,I.tZ)(re,{ref:o,"data-test":"crosslinks",children:e.map((e=>(0,I.tZ)(le,{children:t(e)},i(e))))})),[i,e,t]),p=(0,a.useMemo)((()=>e.slice(0,r).map((e=>(0,I.tZ)(oe,{children:n(e)},i(e))))),[i,e,r,n]);return(0,I.tZ)(ie,{children:(0,I.BX)(ae.u,{placement:"top",title:c?(0,I.BX)(I.HY,{children:[p,u&&(0,I.tZ)("span",{children:(0,l.t)("+ %s more",u)})]}):null,children:[h,d&&(0,I.BX)(se,{ref:s,children:["+",c]})]})})}const de=e=>({key:e.id,to:`/superset/dashboard/${e.id}`,target:"_blank",rel:"noreferer noopener",children:e.dashboard_title}),ue=e=>v.iv`
  color: ${e.colors.grayscale.light5};
  text-decoration: underline;
  &:hover {
    color: inherit;
  }
`,he=[{key:"slice_name",title:(0,l.t)("Chart"),width:"320px",sorter:!0,render:(e,t)=>(0,I.tZ)(A.rU,{to:t.url,children:t.slice_name})},{key:"owners",title:(0,l.t)("Chart owners"),width:"242px",render:(e,t)=>{var n,a;return(0,I.tZ)(ce,{items:null!=(n=null==(a=t.owners)?void 0:a.map((e=>`${e.first_name} ${e.last_name}`)))?n:[]})}},{key:"last_saved_at",title:(0,l.t)("Chart last modified"),width:"209px",sorter:!0,defaultSortOrder:"descend",render:(e,t)=>t.last_saved_at?te().utc(t.last_saved_at).fromNow():null},{key:"last_saved_by.first_name",title:(0,l.t)("Chart last modified by"),width:"216px",sorter:!0,render:(e,t)=>t.last_saved_by?`${t.last_saved_by.first_name} ${t.last_saved_by.last_name}`:null},{key:"dashboards",title:(0,l.t)("Dashboard usage"),width:"420px",render:(e,t)=>(0,I.tZ)(ce,{items:t.dashboards,renderVisibleItem:e=>(0,I.tZ)(A.rU,{...de(e)}),renderTooltipItem:e=>(0,I.tZ)(A.rU,{...de(e),css:ue}),getKey:e=>e.id})}],pe=e=>v.iv`
  && th.ant-table-cell {
    color: ${e.colors.grayscale.light1};
  }

  .ant-table-placeholder {
    display: none;
  }
`,me=(0,I.BX)(I.HY,{children:[(0,I.tZ)(g.Z.PlusOutlined,{iconSize:"m",css:v.iv`
        & > .anticon {
          line-height: 0;
        }
      `}),(0,l.t)("Create chart with dataset")]}),ge=(0,f.iK)(Y.XJ)`
  margin: ${({theme:e})=>13*e.gridUnit}px 0;
`,be=({datasetId:e})=>{const{loading:t,recordCount:n,data:i,onChange:r}=(e=>{const{addDangerToast:t}=(0,G.e1)(),n=(0,a.useMemo)((()=>[{id:"datasource_id",operator:J.p.Equals,value:e}]),[e]),{state:{loading:i,resourceCount:r,resourceCollection:o},fetchData:s}=(0,Q.Yi)("chart",(0,l.t)("chart"),t,!0,[],n),c=(0,a.useMemo)((()=>o.map((e=>({...e,key:e.id})))),[o]),d=(0,a.useCallback)(((e,t,n)=>{var a,i;const r=(null!=(a=e.current)?a:1)-1,l=null!=(i=e.pageSize)?i:0,o=(0,H.Z)(n).filter((({columnKey:e})=>"string"==typeof e)).map((({columnKey:e,order:t})=>({id:e,desc:"descend"===t})));s({pageIndex:r,pageSize:l,sortBy:o,filters:[]})}),[s]);return(0,a.useEffect)((()=>{s({pageIndex:0,pageSize:25,sortBy:[{id:"last_saved_at",desc:!0}],filters:[]})}),[s]),{loading:i,recordCount:r,data:c,onChange:d}})(e),o=(0,a.useCallback)((()=>window.open(`/explore/?dataset_type=table&dataset_id=${e}`,"_blank")),[e]);return(0,I.BX)("div",{css:i.length?null:pe,children:[(0,I.tZ)(L.ZP,{columns:he,data:i,size:L.ex.Middle,defaultPageSize:25,recordCount:n,loading:t,onChange:r}),i.length||t?null:(0,I.tZ)(ge,{image:(0,I.tZ)(q,{}),title:(0,l.t)("No charts"),description:(0,l.t)("This dataset is not used to power any charts."),buttonText:me,buttonAction:o})]})},fe=(0,f.iK)(V.ZP)`
  ${({theme:e})=>`\n  margin-top: ${8.5*e.gridUnit}px;\n  padding-left: ${4*e.gridUnit}px;\n  padding-right: ${4*e.gridUnit}px;\n\n  .ant-tabs-top > .ant-tabs-nav::before {\n    width: ${50*e.gridUnit}px;\n  }\n  `}
`,ve=f.iK.div`
  ${({theme:e})=>`\n  .ant-badge {\n    width: ${8*e.gridUnit}px;\n    margin-left: ${2.5*e.gridUnit}px;\n  }\n  `}
`,ye={USAGE_TEXT:(0,l.t)("Usage"),COLUMNS_TEXT:(0,l.t)("Columns"),METRICS_TEXT:(0,l.t)("Metrics")},xe=({id:e})=>{const{usageCount:t}=(e=>{const[t,n]=(0,a.useState)(0),i=(0,a.useCallback)((()=>r.Z.get({endpoint:`/api/v1/dataset/${e}/related_objects`}).then((({json:e})=>{n(null==e?void 0:e.charts.count)})).catch((e=>{(0,d.Gb)((0,l.t)("There was an error fetching dataset's related objects")),o.Z.error(e)}))),[e]);return(0,a.useEffect)((()=>{e&&i()}),[e,i]),{usageCount:t}})(e),n=(0,I.BX)(ve,{children:[(0,I.tZ)("span",{children:ye.USAGE_TEXT}),t>0&&(0,I.tZ)(j.Z,{count:t})]});return(0,I.BX)(fe,{moreIcon:null,fullWidth:!1,children:[(0,I.tZ)(V.ZP.TabPane,{tab:ye.COLUMNS_TEXT},"1"),(0,I.tZ)(V.ZP.TabPane,{tab:ye.METRICS_TEXT},"2"),(0,I.tZ)(V.ZP.TabPane,{tab:n,children:(0,I.tZ)(be,{datasetId:e})},"3")]})};var we=n(23525),Ze=n(229487);const $e=(e,t,n)=>{var a;return null==t||null==(a=t[e])||null==a.localeCompare?void 0:a.localeCompare(null==n?void 0:n[e])};var Se=n(289419);const Ce=f.iK.div`
  padding: ${({theme:e})=>8*e.gridUnit}px
    ${({theme:e})=>6*e.gridUnit}px;

  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
`,Ue=(0,f.iK)(Y.XJ)`
  max-width: 50%;

  p {
    width: ${({theme:e})=>115*e.gridUnit}px;
  }
`,ze=(0,l.t)("Datasets can be created from database tables or SQL queries. Select a database table to the left or "),Te=(0,l.t)("create dataset from SQL query"),_e=(0,l.t)(" to open SQL Lab. From there you can save the query as a dataset."),Ee=(0,l.t)("Select dataset source"),ke=(0,l.t)("No table columns"),Ne=(0,l.t)("This database table does not contain any data. Please select a different table."),Pe=(0,l.t)("An Error Occurred"),Ie=(0,l.t)("Unable to load columns for the selected table. Please select a different table."),Ke=e=>{const{hasError:t,tableName:n,hasColumns:a}=e;let i="empty-dataset.svg",r=Ee,l=(0,I.BX)(I.HY,{children:[ze,(0,I.tZ)(A.rU,{to:"/sqllab",children:(0,I.tZ)("span",{role:"button",tabIndex:0,children:Te})}),_e]});return t?(r=Pe,l=(0,I.tZ)(I.HY,{children:Ie}),i=void 0):n&&!a&&(i="no-columns.svg",r=ke,l=(0,I.tZ)(I.HY,{children:Ne})),(0,I.tZ)(Ce,{children:(0,I.tZ)(Ue,{image:i,title:r,description:l})})};var Me;!function(e){e.ABSOLUTE="absolute",e.RELATIVE="relative"}(Me||(Me={}));const Oe=f.iK.div`
  ${({theme:e,position:t})=>`\n  position: ${t};\n  margin: ${4*e.gridUnit}px\n    ${3*e.gridUnit}px\n    ${3*e.gridUnit}px\n    ${6*e.gridUnit}px;\n  font-size: ${6*e.gridUnit}px;\n  font-weight: ${e.typography.weights.medium};\n  padding-bottom: ${3*e.gridUnit}px;\n\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n\n  .anticon:first-of-type {\n    margin-right: ${4*e.gridUnit}px;\n  }\n\n  .anticon:nth-of-type(2) {\n    margin-left: ${4*e.gridUnit}px;\n  `}
`,Be=f.iK.div`
  ${({theme:e})=>`\n  margin-left: ${6*e.gridUnit}px;\n  margin-bottom: ${3*e.gridUnit}px;\n  font-weight: ${e.typography.weights.bold};\n  `}
`,Xe=f.iK.div`
  ${({theme:e})=>`\n  padding: ${8*e.gridUnit}px\n    ${6*e.gridUnit}px;\n  box-sizing: border-box;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  `}
`,Re=f.iK.div`
  ${({theme:e})=>`\n  max-width: 50%;\n  width: 200px;\n\n  img {\n    width: 120px;\n    margin-left: 40px;\n  }\n\n  div {\n    width: 100%;\n    margin-top: ${3*e.gridUnit}px;\n    text-align: center;\n    font-weight: ${e.typography.weights.normal};\n    font-size: ${e.typography.sizes.l}px;\n    color: ${e.colors.grayscale.light1};\n  }\n  `}
`,De=f.iK.div`
  ${({theme:e})=>`\n  position: relative;\n  margin: ${3*e.gridUnit}px;\n  margin-left: ${6*e.gridUnit}px;\n  height: calc(100% - ${60*e.gridUnit}px);\n  overflow: auto;\n  `}
`,je=f.iK.div`
  ${({theme:e})=>`\n  position: relative;\n  margin: ${3*e.gridUnit}px;\n  margin-left: ${6*e.gridUnit}px;\n  height: calc(100% - ${30*e.gridUnit}px);\n  overflow: auto;\n  `}
`,Ve=f.iK.div`
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
`,Ae=(0,f.iK)(Ze.Z)`
  ${({theme:e})=>`\n  border: 1px solid ${e.colors.info.base};\n  padding: ${4*e.gridUnit}px;\n  margin: ${6*e.gridUnit}px ${6*e.gridUnit}px\n    ${8*e.gridUnit}px;\n  .view-dataset-button {\n    position: absolute;\n    top: ${4*e.gridUnit}px;\n    right: ${4*e.gridUnit}px;\n    font-weight: ${e.typography.weights.normal};\n\n    &:hover {\n      color: ${e.colors.secondary.dark3};\n      text-decoration: underline;\n    }\n  }\n  `}
`,He=(0,l.t)("Refreshing columns"),Le=(0,l.t)("Table columns"),Ye=(0,l.t)("Loading"),We=["5","10","15","25"],Fe=[{title:"Column Name",dataIndex:"name",key:"name",sorter:(e,t)=>$e("name",e,t)},{title:"Datatype",dataIndex:"type",key:"type",width:"100px",sorter:(e,t)=>$e("type",e,t)}],qe=(0,l.t)("This table already has a dataset associated with it. You can only associate one dataset with a table.\n"),Ge=(0,l.t)("View Dataset"),Qe=({tableName:e,columnList:t,loading:n,hasError:a,datasets:i})=>{var r;const o=(0,f.Fg)(),s=null!=(r=(null==t?void 0:t.length)>0)&&r,c=null==i?void 0:i.map((e=>e.table_name)),d=null==i?void 0:i.find((t=>t.table_name===e));let u,h;return n&&(h=(0,I.tZ)(Xe,{children:(0,I.BX)(Re,{children:[(0,I.tZ)("img",{alt:Ye,src:Se}),(0,I.tZ)("div",{children:He})]})})),n||(u=!n&&e&&s&&!a?(0,I.BX)(I.HY,{children:[(0,I.tZ)(Be,{children:Le}),d?(0,I.tZ)(De,{children:(0,I.tZ)(Ve,{children:(0,I.tZ)(L.ZP,{loading:n,size:L.ex.Small,columns:Fe,data:t,pageSizeOptions:We,defaultPageSize:25})})}):(0,I.tZ)(je,{children:(0,I.tZ)(Ve,{children:(0,I.tZ)(L.ZP,{loading:n,size:L.ex.Small,columns:Fe,data:t,pageSizeOptions:We,defaultPageSize:25})})})]}):(0,I.tZ)(Ke,{hasColumns:s,hasError:a,tableName:e})),(0,I.BX)(I.HY,{children:[e&&(0,I.BX)(I.HY,{children:[(null==c?void 0:c.includes(e))&&(p=d,(0,I.tZ)(Ae,{closable:!1,type:"info",showIcon:!0,message:(0,l.t)("This table already has a dataset"),description:(0,I.BX)(I.HY,{children:[qe,(0,I.tZ)("span",{role:"button",onClick:()=>{window.open(null==p?void 0:p.explore_url,"_blank","noreferrer noopener popup=false")},tabIndex:0,className:"view-dataset-button",children:Ge})]})})),(0,I.BX)(Oe,{position:!n&&s?Me.RELATIVE:Me.ABSOLUTE,title:e||"",children:[e&&(0,I.tZ)(g.Z.Table,{iconColor:o.colors.grayscale.base}),e]})]}),u,h]});var p},Je=({tableName:e,dbId:t,catalog:n,schema:i,setHasColumns:s,datasets:c})=>{const[u,h]=(0,a.useState)([]),[p,m]=(0,a.useState)(!1),[g,b]=(0,a.useState)(!1),f=(0,a.useRef)(e);return(0,a.useEffect)((()=>{f.current=e,e&&i&&t&&(async e=>{const{dbId:t,tableName:a,schema:i}=e;m(!0),null==s||s(!1);const c=`/api/v1/database/${t}/table_metadata/${(0,we.UK)({name:a,catalog:n,schema:i})}`;try{const e=await r.Z.get({endpoint:c});if((e=>{let t=!0;if("string"!=typeof(null==e?void 0:e.name)&&(t=!1),t&&!Array.isArray(e.columns)&&(t=!1),t&&e.columns.length>0){const n=e.columns.some(((e,t)=>{const n=(e=>{let t=!0;const n="The object provided to isITableColumn does match the interface.";return"string"!=typeof(null==e?void 0:e.name)&&(t=!1,console.error(`${n} The property 'name' is required and must be a string`)),t&&"string"!=typeof(null==e?void 0:e.type)&&(t=!1,console.error(`${n} The property 'type' is required and must be a string`)),t})(e);return n||console.error(`The provided object does not match the IDatabaseTable interface. columns[${t}] is invalid and does not match the ITableColumn interface`),!n}));t=!n}return t})(null==e?void 0:e.json)){const t=e.json;t.name===f.current&&(h(t.columns),null==s||s(t.columns.length>0),b(!1))}else h([]),null==s||s(!1),b(!0),(0,d.Gb)((0,l.t)("The API response from %s does not match the IDatabaseTable interface.",c)),o.Z.error((0,l.t)("The API response from %s does not match the IDatabaseTable interface.",c))}catch(e){h([]),null==s||s(!1),b(!0)}finally{m(!1)}})({tableName:e,dbId:t,schema:i})}),[e,t,i]),(0,I.tZ)(Qe,{columnList:u,hasError:g,loading:p,tableName:e,datasets:c})};var et=n(517982),tt=n(961337);const nt=f.iK.div`
  ${({theme:e})=>`\n    padding: ${4*e.gridUnit}px;\n    height: 100%;\n    background-color: ${e.colors.grayscale.light5};\n    position: relative;\n    .emptystate {\n      height: auto;\n      margin-top: ${17.5*e.gridUnit}px;\n    }\n    .section-title {\n      margin-top: ${5.5*e.gridUnit}px;\n      margin-bottom: ${11*e.gridUnit}px;\n      font-weight: ${e.typography.weights.bold};\n    }\n    .table-title {\n      margin-top: ${11*e.gridUnit}px;\n      margin-bottom: ${6*e.gridUnit}px;\n      font-weight: ${e.typography.weights.bold};\n    }\n    .options-list {\n      overflow: auto;\n      position: absolute;\n      bottom: 0;\n      top: ${92.25*e.gridUnit}px;\n      left: ${3.25*e.gridUnit}px;\n      right: 0;\n\n      .no-scrollbar {\n        margin-right: ${4*e.gridUnit}px;\n      }\n\n      .options {\n        cursor: pointer;\n        padding: ${1.75*e.gridUnit}px;\n        border-radius: ${e.borderRadius}px;\n        :hover {\n          background-color: ${e.colors.grayscale.light4}\n        }\n      }\n\n      .options-highlighted {\n        cursor: pointer;\n        padding: ${1.75*e.gridUnit}px;\n        border-radius: ${e.borderRadius}px;\n        background-color: ${e.colors.primary.dark1};\n        color: ${e.colors.grayscale.light5};\n      }\n\n      .options, .options-highlighted {\n        display: flex;\n        align-items: center;\n        justify-content: space-between;\n      }\n    }\n    form > span[aria-label="refresh"] {\n      position: absolute;\n      top: ${69*e.gridUnit}px;\n      left: ${42.75*e.gridUnit}px;\n      font-size: ${4.25*e.gridUnit}px;\n    }\n    .table-form {\n      margin-bottom: ${8*e.gridUnit}px;\n    }\n    .loading-container {\n      position: absolute;\n      top: ${89.75*e.gridUnit}px;\n      left: 0;\n      right: 0;\n      text-align: center;\n      img {\n        width: ${20*e.gridUnit}px;\n        margin-bottom: ${2.5*e.gridUnit}px;\n      }\n      p {\n        color: ${e.colors.grayscale.light1};\n      }\n    }\n`}
`;function at({setDataset:e,dataset:t,datasetNames:n}){const{addDangerToast:i}=(0,G.e1)(),r=(0,a.useCallback)((t=>{e({type:h.SelectDatabase,payload:{db:t}})}),[e]);(0,a.useEffect)((()=>{const e=(0,tt.rV)(tt.dR.Database,null);e&&r(e)}),[r]);const o=(0,a.useCallback)((e=>(0,I.tZ)(et.ez,{table:null!=n&&n.includes(e.value)?{...e,extra:{warning_markdown:(0,l.t)("This table already has a dataset")}}:e})),[n]);return(0,I.tZ)(nt,{children:(0,I.tZ)(et.ZP,{database:null==t?void 0:t.db,handleError:i,emptyState:(0,Y.UX)(!1),onDbChange:r,onCatalogChange:t=>{t&&e({type:h.SelectCatalog,payload:{name:"catalog",value:t}})},onSchemaChange:t=>{t&&e({type:h.SelectSchema,payload:{name:"schema",value:t}})},onTableSelectChange:t=>{e({type:h.SelectTable,payload:{name:"table_name",value:t}})},sqlLabMode:!1,customTableOptionLabelRenderer:o,...(null==t?void 0:t.catalog)&&{catalog:t.catalog},...(null==t?void 0:t.schema)&&{schema:t.schema}})})}var it=n(797381),rt=n(203741);const lt=["db","schema","table_name"],ot=[rt.Ph,rt.FY,rt.Eh,rt.TA],st=(0,G.ZP)((function({datasetObject:e,addDangerToast:t,hasColumns:n=!1,datasets:a}){const r=(0,i.k6)(),{createResource:o}=(0,Q.LE)("dataset",(0,l.t)("dataset"),t),s=(0,l.t)("Select a database table."),c=(0,l.t)("Create dataset and create chart"),d=!(null!=e&&e.table_name)||!n||(null==a?void 0:a.includes(null==e?void 0:e.table_name));return(0,I.BX)(I.HY,{children:[(0,I.tZ)(m.Z,{onClick:()=>{if(e){const t=(e=>{let t=0;const n=Object.keys(e).reduce(((n,a)=>(lt.includes(a)&&e[a]&&(t+=1),t)),0);return ot[n]})(e);(0,it.logEvent)(t,e)}else(0,it.logEvent)(rt.Ph,{});r.goBack()},children:(0,l.t)("Cancel")}),(0,I.tZ)(m.Z,{buttonStyle:"primary",disabled:d,tooltip:null!=e&&e.table_name?void 0:s,onClick:()=>{if(e){var t;const n={database:null==(t=e.db)?void 0:t.id,catalog:e.catalog,schema:e.schema,table_name:e.table_name};o(n).then((t=>{t&&"number"==typeof t&&((0,it.logEvent)(rt.P$,e),r.push(`/chart/add/?dataset=${e.table_name}`))}))}},children:c})]})}));var ct=n(280663);function dt({header:e,leftPanel:t,datasetPanel:n,rightPanel:a,footer:i}){const r=(0,f.Fg)();return(0,I.BX)(y,{"data-test":"dataset-layout-wrapper",children:[e&&(0,I.tZ)(U,{children:e}),(0,I.BX)($,{children:[t&&(0,I.tZ)(ct.Z,{id:"dataset",initialWidth:80*r.gridUnit,minWidth:80*r.gridUnit,enable:!0,children:e=>(0,I.tZ)(x,{width:e,children:(0,I.tZ)(T,{children:t})})}),(0,I.BX)(w,{children:[(0,I.BX)(S,{children:[n&&(0,I.tZ)(_,{children:n}),a&&(0,I.tZ)(E,{children:a})]}),(0,I.tZ)(C,{children:i&&(0,I.tZ)(k,{children:i})})]})]})]})}function ut(e,t){const n={...e||{}};switch(t.type){case h.SelectDatabase:return{...n,...t.payload,catalog:null,schema:null,table_name:null};case h.SelectCatalog:return{...n,[t.payload.name]:t.payload.value,schema:null,table_name:null};case h.SelectSchema:return{...n,[t.payload.name]:t.payload.value,table_name:null};case h.SelectTable:return{...n,[t.payload.name]:t.payload.value};case h.ChangeDataset:return{...n,[t.payload.name]:t.payload.value};default:return null}}const ht="/tablemodelview/list/?pageIndex=0&sortColumn=changed_on_delta_humanized&sortOrder=desc";function pt(){const[e,t]=(0,a.useReducer)(ut,null),[n,r]=(0,a.useState)(!1),[l,o]=(0,a.useState)(!1),{datasets:s,datasetNames:c}=u(null==e?void 0:e.db,null==e?void 0:e.schema),{datasetId:d}=(0,i.UO)();return(0,a.useEffect)((()=>{Number.isNaN(parseInt(d,10))||o(!0)}),[d]),(0,I.tZ)(dt,{header:(0,I.tZ)(X,{setDataset:t,title:null==e?void 0:e.table_name}),leftPanel:l?null:(0,I.tZ)(at,{setDataset:t,dataset:e,datasetNames:c}),datasetPanel:l?(0,I.tZ)(xe,{id:d}):(0,I.tZ)(Je,{tableName:null==e?void 0:e.table_name,dbId:null==e||null==(h=e.db)?void 0:h.id,catalog:null==e?void 0:e.catalog,schema:null==e?void 0:e.schema,setHasColumns:r,datasets:s}),footer:(0,I.tZ)(st,{url:ht,datasetObject:e,hasColumns:n,datasets:c})});var h}}}]);
//# sourceMappingURL=9db71255060f3661d368.chunk.js.map