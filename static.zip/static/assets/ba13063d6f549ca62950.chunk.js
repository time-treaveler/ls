"use strict";(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[9820],{94301:(n,e,i)=>{i.d(e,{Tc:()=>A,UX:()=>T,XJ:()=>f,x3:()=>$});var t,l=i(751995),r=i(211965),a=i(61988),o=i(104715),s=i(835932),d=i(135944);!function(n){n[n.Small=0]="Small",n[n.Medium=1]="Medium",n[n.Big=2]="Big"}(t||(t={}));const c=l.iK.div`
  ${({theme:n})=>r.iv`
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    align-items: center;
    justify-content: center;
    padding: ${4*n.gridUnit}px;
    text-align: center;

    & .ant-empty-image svg {
      width: auto;
    }

    & a,
    & span[role='button'] {
      color: inherit;
      text-decoration: underline;
      &:hover {
        color: ${n.colors.grayscale.base};
      }
    }
  `}
`,p=l.iK.div``,h=l.iK.p`
  ${({theme:n})=>r.iv`
    font-size: ${n.typography.sizes.m}px;
    color: ${n.colors.grayscale.light1};
    margin: ${2*n.gridUnit}px 0 0 0;
    font-weight: ${n.typography.weights.bold};
  `}
`,g=(0,l.iK)(h)`
  ${({theme:n})=>r.iv`
    font-size: ${n.typography.sizes.l}px;
    color: ${n.colors.grayscale.light1};
    margin-top: ${4*n.gridUnit}px;
  `}
`,m=l.iK.p`
  ${({theme:n})=>r.iv`
    font-size: ${n.typography.sizes.s}px;
    color: ${n.colors.grayscale.light1};
    margin: ${2*n.gridUnit}px 0 0 0;
  `}
`,u=(0,l.iK)(m)`
  ${({theme:n})=>r.iv`
    font-size: ${n.typography.sizes.m}px;
  `}
`,b=(0,l.iK)(m)`
  ${({theme:n})=>r.iv`
    margin-top: ${n.gridUnit}px;
    line-height: 1.2;
  `}
`,x=(0,l.iK)(s.Z)`
  ${({theme:n})=>r.iv`
    margin-top: ${4*n.gridUnit}px;
    z-index: 1;
  `}
`,y=n=>"string"==typeof n?`/static/assets/images/${n}`:n,v=n=>{switch(n){case t.Small:return{height:"50px"};case t.Medium:return{height:"80px"};case t.Big:return{height:"150px"};default:return{height:"50px"}}},w=({image:n,size:e})=>(0,d.tZ)(o.HY,{description:!1,image:y(n),imageStyle:v(e)}),Z=n=>{n.preventDefault(),n.stopPropagation()},f=({title:n,image:e,description:i,buttonAction:l,buttonText:a,className:o})=>(0,d.BX)(c,{className:o,children:[e&&(0,d.tZ)(w,{image:e,size:t.Big}),(0,d.BX)(p,{css:n=>r.iv`
        max-width: ${150*n.gridUnit}px;
      `,children:[(0,d.tZ)(g,{children:n}),i&&(0,d.tZ)(u,{children:i}),l&&a&&(0,d.tZ)(x,{buttonStyle:"primary",onClick:l,onMouseDown:Z,children:a})]})]}),$=({title:n,image:e,description:i,buttonAction:l,buttonText:a})=>(0,d.BX)(c,{children:[e&&(0,d.tZ)(w,{image:e,size:t.Medium}),(0,d.BX)(p,{css:n=>r.iv`
        max-width: ${100*n.gridUnit}px;
      `,children:[(0,d.tZ)(h,{children:n}),i&&(0,d.tZ)(m,{children:i}),a&&l&&(0,d.tZ)(x,{buttonStyle:"primary",onClick:l,onMouseDown:Z,children:a})]})]}),A=({title:n,image:e,description:i})=>(0,d.BX)(c,{children:[e&&(0,d.tZ)(w,{image:e,size:t.Small}),(0,d.BX)(p,{css:n=>r.iv`
        max-width: ${75*n.gridUnit}px;
      `,children:[(0,d.tZ)(h,{children:n}),i&&(0,d.tZ)(b,{children:i})]})]}),k={NO_DATABASES_MATCH_TITLE:(0,a.t)("No databases match your search"),NO_DATABASES_AVAILABLE_TITLE:(0,a.t)("There are no databases available"),MANAGE_YOUR_DATABASES_TEXT:(0,a.t)("Manage your databases"),HERE_TEXT:(0,a.t)("here")},T=n=>(0,d.tZ)(A,{image:"empty.svg",title:n?k.NO_DATABASES_MATCH_TITLE:k.NO_DATABASES_AVAILABLE_TITLE,description:(0,d.BX)("p",{children:[k.MANAGE_YOUR_DATABASES_TEXT," ",(0,d.tZ)("a",{href:"/databaseview/list",children:k.HERE_TEXT})]})})},64158:(n,e,i)=>{i.d(e,{Z:()=>p});var t=i(751995),l=i(693967),r=i.n(l),a=i(135944);const o=t.iK.ul`
  display: inline-block;
  margin: 16px 0;
  padding: 0;

  li {
    display: inline;
    margin: 0 4px;

    span {
      padding: 8px 12px;
      text-decoration: none;
      background-color: ${({theme:n})=>n.colors.grayscale.light5};
      border-radius: ${({theme:n})=>n.borderRadius}px;

      &:hover,
      &:focus {
        z-index: 2;
        color: ${({theme:n})=>n.colors.grayscale.dark1};
        background-color: ${({theme:n})=>n.colors.grayscale.light3};
      }
    }

    &.disabled {
      span {
        background-color: transparent;
        cursor: default;

        &:focus {
          outline: none;
        }
      }
    }
    &.active {
      span {
        z-index: 3;
        color: ${({theme:n})=>n.colors.grayscale.light5};
        cursor: default;
        background-color: ${({theme:n})=>n.colors.primary.base};

        &:focus {
          outline: none;
        }
      }
    }
  }
`;function s({children:n}){return(0,a.tZ)(o,{role:"navigation",children:n})}s.Next=function({disabled:n,onClick:e}){return(0,a.tZ)("li",{className:r()({disabled:n}),children:(0,a.tZ)("span",{role:"button",tabIndex:n?-1:0,onClick:i=>{i.preventDefault(),n||e(i)},children:"»"})})},s.Prev=function({disabled:n,onClick:e}){return(0,a.tZ)("li",{className:r()({disabled:n}),children:(0,a.tZ)("span",{role:"button",tabIndex:n?-1:0,onClick:i=>{i.preventDefault(),n||e(i)},children:"«"})})},s.Item=function({active:n,children:e,onClick:i}){return(0,a.tZ)("li",{className:r()({active:n}),children:(0,a.tZ)("span",{role:"button",tabIndex:n?-1:0,onClick:e=>{e.preventDefault(),n||i(e)},children:e})})},s.Ellipsis=function({disabled:n,onClick:e}){return(0,a.tZ)("li",{className:r()({disabled:n}),children:(0,a.tZ)("span",{role:"button",tabIndex:n?-1:0,onClick:i=>{i.preventDefault(),n||e(i)},children:"…"})})};const d=s;var c=i(452630);const p=(0,c.YM)({WrapperComponent:d,itemTypeToComponent:{[c.iB.PAGE]:({value:n,isActive:e,onClick:i})=>(0,a.tZ)(d.Item,{active:e,onClick:i,children:n}),[c.iB.ELLIPSIS]:({isActive:n,onClick:e})=>(0,a.tZ)(d.Ellipsis,{disabled:n,onClick:e}),[c.iB.PREVIOUS_PAGE_LINK]:({isActive:n,onClick:e})=>(0,a.tZ)(d.Prev,{disabled:n,onClick:e}),[c.iB.NEXT_PAGE_LINK]:({isActive:n,onClick:e})=>(0,a.tZ)(d.Next,{disabled:n,onClick:e}),[c.iB.FIRST_PAGE_LINK]:()=>null,[c.iB.LAST_PAGE_LINK]:()=>null}})},397754:(n,e,i)=>{i.d(e,{Z:()=>c});var t=i(667294),l=i(693967),r=i.n(l),a=i(751995),o=i(313322),s=i(135944);const d=a.iK.table`
  ${({theme:n})=>`\n    background-color: ${n.colors.grayscale.light5};\n    border-collapse: separate;\n    border-radius: ${n.borderRadius}px;\n\n    thead > tr > th {\n      border: 0;\n    }\n\n    tbody {\n      tr:first-of-type > td {\n        border-top: 0;\n      }\n    }\n    th {\n      background: ${n.colors.grayscale.light5};\n      position: sticky;\n      top: 0;\n\n      &:first-of-type {\n        padding-left: ${4*n.gridUnit}px;\n      }\n\n      &.xs {\n        min-width: 25px;\n      }\n      &.sm {\n        min-width: 50px;\n      }\n      &.md {\n        min-width: 75px;\n      }\n      &.lg {\n        min-width: 100px;\n      }\n      &.xl {\n        min-width: 150px;\n      }\n      &.xxl {\n        min-width: 200px;\n      }\n\n      span {\n        white-space: nowrap;\n        display: flex;\n        align-items: center;\n        line-height: 2;\n      }\n\n      svg {\n        display: inline-block;\n        position: relative;\n      }\n    }\n\n    td {\n      &.xs {\n        width: 25px;\n      }\n      &.sm {\n        width: 50px;\n      }\n      &.md {\n        width: 75px;\n      }\n      &.lg {\n        width: 100px;\n      }\n      &.xl {\n        width: 150px;\n      }\n      &.xxl {\n        width: 200px;\n      }\n    }\n\n    .table-cell-loader {\n      position: relative;\n\n      .loading-bar {\n        background-color: ${n.colors.secondary.light4};\n        border-radius: 7px;\n\n        span {\n          visibility: hidden;\n        }\n      }\n\n      .empty-loading-bar {\n        display: inline-block;\n        width: 100%;\n        height: 1.2em;\n      }\n    }\n\n    .actions {\n      white-space: nowrap;\n      min-width: 100px;\n\n      svg,\n      i {\n        margin-right: 8px;\n\n        &:hover {\n          path {\n            fill: ${n.colors.primary.base};\n          }\n        }\n      }\n    }\n\n    .table-row {\n      .actions {\n        opacity: 0;\n        font-size: ${n.typography.sizes.xl}px;\n        display: flex;\n      }\n\n      &:hover {\n        background-color: ${n.colors.secondary.light5};\n\n        .actions {\n          opacity: 1;\n          transition: opacity ease-in ${n.transitionTiming}s;\n        }\n      }\n    }\n\n    .table-row-selected {\n      background-color: ${n.colors.secondary.light4};\n\n      &:hover {\n        background-color: ${n.colors.secondary.light4};\n      }\n    }\n\n    .table-cell {\n      font-feature-settings: 'tnum' 1;\n      text-overflow: ellipsis;\n      overflow: hidden;\n      max-width: 320px;\n      line-height: 1;\n      vertical-align: middle;\n      &:first-of-type {\n        padding-left: ${4*n.gridUnit}px;\n      }\n      &__wrap {\n        white-space: normal;\n      }\n      &__nowrap {\n        white-space: nowrap;\n      }\n    }\n\n    @keyframes loading-shimmer {\n      40% {\n        background-position: 100% 0;\n      }\n\n      100% {\n        background-position: 100% 0;\n      }\n    }\n  `}
`;d.displayName="table";const c=(0,t.memo)((({getTableProps:n,getTableBodyProps:e,prepareRow:i,headerGroups:t,columns:l,rows:a,loading:c,highlightRowId:p,columnsForWrapText:h})=>(0,s.BX)(d,{...n(),className:"table table-hover","data-test":"listview-table",children:[(0,s.tZ)("thead",{children:t.map((n=>(0,s.tZ)("tr",{...n.getHeaderGroupProps(),children:n.headers.map((n=>{let e=(0,s.tZ)(o.Z.Sort,{});return n.isSorted&&n.isSortedDesc?e=(0,s.tZ)(o.Z.SortDesc,{}):n.isSorted&&!n.isSortedDesc&&(e=(0,s.tZ)(o.Z.SortAsc,{})),n.hidden?null:(0,s.tZ)("th",{...n.getHeaderProps(n.canSort?n.getSortByToggleProps():{}),"data-test":"sort-header",className:r()({[n.size||""]:n.size}),children:(0,s.BX)("span",{children:[n.render("Header"),n.canSort&&e]})})}))})))}),(0,s.BX)("tbody",{...e(),children:[c&&0===a.length&&[...new Array(12)].map(((n,e)=>(0,s.tZ)("tr",{children:l.map(((n,e)=>n.hidden?null:(0,s.tZ)("td",{className:r()("table-cell",{"table-cell-loader":c}),children:(0,s.tZ)("span",{className:"loading-bar empty-loading-bar",role:"progressbar","aria-label":"loading"})},e)))},e))),a.length>0&&a.map((n=>{i(n);const e=n.original.id;return(0,s.tZ)("tr",{"data-test":"table-row",...n.getRowProps(),className:r()("table-row",{"table-row-selected":n.isSelected||void 0!==e&&e===p}),children:n.cells.map((n=>{if(n.column.hidden)return null;const e=n.column.cellProps||{},i=null==h?void 0:h.includes(n.column.Header);return(0,s.tZ)("td",{"data-test":"table-row-cell",className:r()("table-cell table-cell__"+(i?"wrap":"nowrap"),{"table-cell-loader":c,[n.column.size||""]:n.column.size}),...n.getCellProps(),...e,children:(0,s.tZ)("span",{className:r()({"loading-bar":c}),role:c?"progressbar":void 0,children:(0,s.tZ)("span",{"data-test":"cell-text",children:n.render("Cell")})})})}))})}))]})]})))}}]);
//# sourceMappingURL=ba13063d6f549ca62950.chunk.js.map